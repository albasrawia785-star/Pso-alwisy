import React, { useEffect, useState } from 'react';
import {
  Printer,
  MapPin,
  Phone,
  Image as ImageIcon,
  RefreshCw,
  Save,
} from 'lucide-react';
import { AppSettings, ElectronPrinter } from '../types';
import {
  FIXED_BANNER_IMAGE,
  FIXED_SHOP_ADDRESS,
  FIXED_SHOP_PHONE,
} from '../utils/storage';

interface SettingsViewProps {
  settings: AppSettings;
  onSave: (nextSettings: AppSettings) => Promise<void> | void;
  onTestPrint: (draftSettings: AppSettings) => Promise<void> | void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSave,
  onTestPrint,
  onNotify,
}) => {
  const [draft, setDraft] = useState<AppSettings>(settings);
  const [printers, setPrinters] = useState<ElectronPrinter[]>([]);
  const [loadingPrinters, setLoadingPrinters] = useState(false);

  const hasElectronPrinters =
    typeof window !== 'undefined' && typeof window.electronAPI?.getPrinters === 'function';

  useEffect(() => {
    setDraft(settings);
  }, [settings]);

  useEffect(() => {
    if (hasElectronPrinters) {
      void fetchPrinters();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasElectronPrinters]);

  const fetchPrinters = async () => {
    if (!window.electronAPI?.getPrinters) return;
    setLoadingPrinters(true);
    try {
      const list = await window.electronAPI.getPrinters();
      setPrinters(Array.isArray(list) ? list : []);
    } catch {
      onNotify('error', 'تعذر جلب قائمة الطابعات من النظام');
    } finally {
      setLoadingPrinters(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void onSave({
      ...draft,
      bannerImage: FIXED_BANNER_IMAGE,
      shopAddress: FIXED_SHOP_ADDRESS,
      shopPhone: FIXED_SHOP_PHONE,
      paperSize: 'A4_PORTRAIT',
    });
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-4xl space-y-5">
      {/* 1. Official Saved Receipt Banner Preview (Read-only) */}
      <section className="bg-white rounded-xl border border-[#E2E8EE] p-5 space-y-3.5">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-[#1E293B] font-extrabold text-base">
            <ImageIcon className="w-4.5 h-4.5 text-[#0F766E]" />
            <span>ترويسة الوصل المطبوع</span>
          </div>
          <span className="text-xs font-semibold text-[#64748B]">
            الترويسة الرسمية محفوظة ومثبتة في الفواتير
          </span>
        </div>

        <div className="w-full rounded-lg overflow-hidden border border-[#DCE4EC] bg-white p-2 flex items-center justify-center">
          <img
            src={FIXED_BANNER_IMAGE}
            alt="ترويسة أحمد القيسي للإطارات والبطاريات"
            referrerPolicy="no-referrer"
            className="w-full h-auto object-contain block"
          />
        </div>
      </section>

      {/* 2. Fixed Shop Information (Read-only, Edit Fields Hidden) */}
      <section className="bg-white rounded-xl border border-[#E2E8EE] p-5 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-[#1E293B] font-extrabold text-base">
            <MapPin className="w-4.5 h-4.5 text-[#0F766E]" />
            <span>بيانات المحل الثابتة</span>
          </div>
          <span className="text-xs font-semibold text-[#64748B]">
            تظهر تلقائياً في تذييل الفاتورة
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div className="rounded-lg border border-[#E2E8EE] bg-[#F8FAFB] px-4 py-3 flex items-center gap-2.5">
            <MapPin className="w-4 h-4 text-[#0F766E] shrink-0" />
            <div className="text-sm font-bold text-[#1E293B]">{FIXED_SHOP_ADDRESS}</div>
          </div>

          <div className="rounded-lg border border-[#E2E8EE] bg-[#F8FAFB] px-4 py-3 flex items-center gap-2.5">
            <Phone className="w-4 h-4 text-[#0F766E] shrink-0" />
            <div dir="ltr" className="text-sm font-bold text-[#1E293B] tabular-nums">
              {FIXED_SHOP_PHONE}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Direct Printer & A4 Print Settings */}
      <section className="bg-white rounded-xl border border-[#E2E8EE] p-5 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-[#1E293B] font-extrabold text-base">
            <Printer className="w-4.5 h-4.5 text-[#0F766E]" />
            <span>إعدادات الطباعة والطابعة المباشرة</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-[#475569]">
              مقاس الورق: A4 عمودي (210 × 297 ملم)
            </span>
            {hasElectronPrinters && (
              <button
                type="button"
                onClick={fetchPrinters}
                disabled={loadingPrinters}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F766E] hover:text-[#115E59] cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingPrinters ? 'animate-spin' : ''}`} />
                <span>تحديث القائمة</span>
              </button>
            )}
          </div>
        </div>

        {hasElectronPrinters && (
          <div className="space-y-4">
            <div>
              <label
                htmlFor="printer-select"
                className="block text-xs font-bold text-[#475569] mb-1.5"
              >
                الطابعة الافتراضية
              </label>
              <select
                id="printer-select"
                value={draft.selectedPrinter}
                onChange={(e) => setDraft({ ...draft, selectedPrinter: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-[#CBD5E1] bg-[#F8FAFB] focus:bg-white text-[#1E293B] font-semibold text-sm focus:outline-none focus:border-[#0F766E]"
              >
                <option value="">الطابعة الافتراضية للنظام (تلقائي)</option>
                {printers.map((p) => (
                  <option key={p.name} value={p.name}>
                    {p.displayName || p.name}
                    {p.isDefault ? ' (الافتراضية)' : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-between gap-4 pt-2 border-t border-[#EEF2F5]">
              <div>
                <div className="font-bold text-sm text-[#1E293B]">
                  الطباعة الفورية الصامتة (بدون نافذة معاينة)
                </div>
                <div className="text-xs text-[#64748B] mt-0.5">
                  يرسل الفاتورة مباشرة إلى الطابعة المختارة عند الضغط على &quot;طباعة الفاتورة&quot;
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={draft.silentPrint}
                onClick={() => setDraft({ ...draft, silentPrint: !draft.silentPrint })}
                className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors cursor-pointer ${
                  draft.silentPrint ? 'bg-[#0F766E]' : 'bg-[#CBD5E1]'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    draft.silentPrint ? '-translate-x-6' : '-translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        )}

        <div className="pt-3 border-t border-[#EEF2F5] flex items-center justify-between gap-3 flex-wrap">
          <span className="text-xs font-semibold text-[#64748B]">
            تأكد من توصيل كيبل الطابعة وتشغيلها ثم اختبر الطباعة الفورية:
          </span>
          <button
            type="button"
            onClick={() =>
              void onTestPrint({
                ...draft,
                bannerImage: FIXED_BANNER_IMAGE,
                shopAddress: FIXED_SHOP_ADDRESS,
                shopPhone: FIXED_SHOP_PHONE,
                paperSize: 'A4_PORTRAIT',
              })
            }
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFB] hover:border-[#0F766E] text-[#1E293B] text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Printer className="w-4 h-4 text-[#0F766E]" />
            <span>طباعة تجريبية لفحص الطابعة</span>
          </button>
        </div>
      </section>

      {/* Save Settings Bar (shown when Electron printer options are present) */}
      {hasElectronPrinters && (
        <div className="flex items-center justify-end gap-3 pt-1">
          <button
            type="button"
            onClick={() => setDraft(settings)}
            className="px-5 py-2.5 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFB] text-[#475569] font-bold text-sm transition-colors cursor-pointer"
          >
            تراجع عن التعديلات
          </button>
          <button
            type="submit"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg bg-[#0F766E] hover:bg-[#115E59] text-white font-bold text-sm transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>حفظ الإعدادات</span>
          </button>
        </div>
      )}
    </form>
  );
};
