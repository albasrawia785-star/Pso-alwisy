import React, { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import {
  Search,
  Printer,
  Trash2,
  Download,
  Upload,
  FileText,
  Eye,
  Check,
  X,
  AlertTriangle,
  ChevronRight,
  ChevronLeft,
  ChevronsRight,
  ChevronsLeft,
  Loader2,
  Plus,
} from 'lucide-react';
import { Invoice, PaymentMethod } from '../types';
import { formatIqd, getInvoiceTotalIqd, getPaymentMethodLabel } from '../utils/storage';

interface InventoryViewProps {
  isLoading?: boolean;
  invoices: Invoice[];
  onLoadInvoice: (invoice: Invoice, autoPrint?: boolean) => void;
  onDeleteInvoice: (id: string) => void;
  onImportInvoices: (imported: Invoice[]) => void;
  onGoToCashier: () => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

const PAGE_SIZE_OPTIONS = [25, 50, 100] as const;

export const InventoryView: React.FC<InventoryViewProps> = ({
  isLoading = false,
  invoices,
  onLoadInvoice,
  onDeleteInvoice,
  onImportInvoices,
  onGoToCashier,
  onNotify,
}) => {
  const [query, setQuery] = useState('');
  const deferredQuery = useDeferredValue(query);
  const [paymentFilter, setPaymentFilter] = useState<'all' | PaymentMethod>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(50);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  const filteredInvoices = useMemo(() => {
    const q = deferredQuery.trim().toLowerCase();
    return invoices.filter((inv) => {
      if (paymentFilter !== 'all' && inv.paymentMethod !== paymentFilter) {
        return false;
      }
      if (!q) return true;
      const inSerial = inv.serialNumber.toLowerCase().includes(q);
      const inName = inv.customerName.toLowerCase().includes(q);
      const inPhone = inv.customerPhone.toLowerCase().includes(q);
      const inNotes = inv.customerNotes.toLowerCase().includes(q);
      const inItems = inv.items.some((item) => item.name.toLowerCase().includes(q));
      return inSerial || inName || inPhone || inNotes || inItems;
    });
  }, [invoices, deferredQuery, paymentFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredInvoices.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);

  useEffect(() => {
    setCurrentPage(1);
  }, [deferredQuery, paymentFilter, pageSize]);

  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [currentPage, totalPages]);

  const paginatedInvoices = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredInvoices.slice(start, start + pageSize);
  }, [filteredInvoices, safePage, pageSize]);

  const pageNumbers = useMemo(() => {
    const maxButtons = 5;
    if (totalPages <= maxButtons) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    const half = Math.floor(maxButtons / 2);
    let start = Math.max(1, safePage - half);
    const end = Math.min(totalPages, start + maxButtons - 1);
    start = Math.max(1, end - maxButtons + 1);
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }, [safePage, totalPages]);

  const goToPage = (page: number) => {
    const clamped = Math.max(1, Math.min(totalPages, page));
    setCurrentPage(clamped);
    tableContainerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const totalSalesIqd = useMemo(() => {
    return filteredInvoices.reduce((sum, inv) => sum + getInvoiceTotalIqd(inv), 0);
  }, [filteredInvoices]);

  const cashTotalIqd = useMemo(() => {
    return filteredInvoices
      .filter((inv) => inv.paymentMethod === 'cash')
      .reduce((sum, inv) => sum + getInvoiceTotalIqd(inv), 0);
  }, [filteredInvoices]);

  const rangeStart = filteredInvoices.length === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const rangeEnd = Math.min(filteredInvoices.length, safePage * pageSize);

  const handleExportJson = () => {
    try {
      const payload = {
        app: 'AlQaisi-POS',
        version: 1,
        exportedAt: new Date().toISOString(),
        invoices,
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: 'application/json;charset=utf-8',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const today = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `alqaisi-pos-backup-${today}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onNotify('success', `تم تصدير النسخة الاحتياطية (${invoices.length} فاتورة) بنجاح`);
    } catch {
      onNotify('error', 'حدث خطأ أثناء تصدير النسخة الاحتياطية');
    }
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onerror = () => {
      onNotify('error', 'فشل قراءة ملف النسخة الاحتياطية');
    };
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const rawList: unknown = Array.isArray(parsed) ? parsed : parsed?.invoices;
        if (!Array.isArray(rawList)) {
          onNotify('error', 'صيغة ملف النسخة الاحتياطية غير صحيحة');
          return;
        }
        const validInvoices = rawList.filter(
          (item): item is Invoice =>
            Boolean(item) &&
            typeof item === 'object' &&
            typeof (item as Invoice).id === 'string' &&
            typeof (item as Invoice).serialNumber === 'string' &&
            Array.isArray((item as Invoice).items)
        );
        if (validInvoices.length === 0 && rawList.length > 0) {
          onNotify('error', 'لم يتم العثور على فواتير صالحة داخل الملف');
          return;
        }
        onImportInvoices(validInvoices);
      } catch {
        onNotify('error', 'تعذر قراءة ملف JSON — تأكد من سلامة الملف');
      } finally {
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };
    reader.readAsText(file, 'utf-8');
  };

  return (
    <div ref={tableContainerRef} className="space-y-5">
      {/* KPI Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-white border border-[#E2E8EE] px-5 py-4">
          <div className="text-xs font-bold text-[#64748B]">عدد الفواتير المعروضة</div>
          <div className="text-2xl font-extrabold text-[#1E293B] tabular-nums mt-1">
            {filteredInvoices.length.toLocaleString('en-US')}
            <span className="text-xs font-semibold text-[#64748B] mr-1.5">
              من أصل {invoices.length.toLocaleString('en-US')}
            </span>
          </div>
        </div>

        <div className="rounded-xl bg-white border border-[#E2E8EE] px-5 py-4">
          <div className="text-xs font-bold text-[#64748B]">إجمالي المبيعات (دينار عراقي)</div>
          <div className="text-2xl font-extrabold text-[#0F766E] tabular-nums mt-1">
            {formatIqd(totalSalesIqd)}
            <span className="text-xs font-bold text-[#64748B] mr-1.5">د.ع</span>
          </div>
        </div>

        <div className="rounded-xl bg-white border border-[#E2E8EE] px-5 py-4">
          <div className="text-xs font-bold text-[#64748B]">إجمالي المبيعات النقدية</div>
          <div className="text-2xl font-extrabold text-[#15803D] tabular-nums mt-1">
            {formatIqd(cashTotalIqd)}
            <span className="text-xs font-bold text-[#64748B] mr-1.5">د.ع</span>
          </div>
        </div>
      </div>

      {/* Main Ledger Card */}
      <section className="bg-white rounded-xl border border-[#E2E8EE] overflow-hidden">
        {/* Search, Filter & Backup Toolbar */}
        <div className="p-4 border-b border-[#E2E8EE] flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[240px]">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-[#64748B] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                aria-label="بحث في سجل الفواتير"
                className="w-full h-10 pr-9 pl-3 rounded-lg border border-[#CBD5E1] bg-[#F8FAFB] hover:bg-white focus:bg-white text-sm font-semibold text-[#1E293B] focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[rgba(15,118,110,0.18)] transition-colors"
              />
            </div>

            {/* Payment filter segmented buttons */}
            <div className="flex items-center gap-1 p-1 bg-[#F1F5F7] border border-[#E2E8EE] rounded-lg">
              {(
                [
                  { id: 'all', label: 'الكل' },
                  { id: 'cash', label: 'نقداً' },
                  { id: 'card', label: 'بطاقة' },
                  { id: 'transfer', label: 'تحويل' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setPaymentFilter(tab.id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    paymentFilter === tab.id
                      ? 'bg-[#0F766E] text-white shadow-xs'
                      : 'text-[#475569] hover:text-[#1E293B]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Backup Export / Import */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleExportJson}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#F0FDFA] hover:bg-[#CCFBF1] text-[#0F766E] border border-[#99F6E4] text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>تصدير نسخة احتياطية</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleImportJson}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white hover:bg-[#F8FAFB] text-[#334155] border border-[#CBD5E1] text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Upload className="w-4 h-4" />
              <span>استيراد</span>
            </button>
          </div>
        </div>

        {/* Invoices Table */}
        <div className="overflow-x-auto">
          {isLoading ? (
            <div className="py-20 px-6 text-center space-y-2.5">
              <Loader2 className="w-9 h-9 text-[#0F766E] mx-auto animate-spin" />
              <div className="text-sm font-bold text-[#1E293B]">
                جارٍ تحميل سجل الفواتير من قاعدة البيانات المحلية...
              </div>
            </div>
          ) : filteredInvoices.length === 0 ? (
            <div className="py-20 px-6 text-center space-y-3">
              <FileText className="w-11 h-11 text-[#94A3B8] mx-auto" />
              <div className="text-base font-bold text-[#1E293B]">
                {invoices.length === 0
                  ? 'لا توجد فواتير محفوظة في السجل بعد'
                  : 'لا توجد نتائج تطابق بحثك'}
              </div>
              <p className="text-sm text-[#64748B] max-w-md mx-auto">
                {invoices.length === 0
                  ? 'عند حفظ أو طباعة أي فاتورة من شاشة نقطة البيع ستُضاف تلقائياً هنا برقم تسلسلي.'
                  : 'جرب البحث برقم فاتورة آخر أو امسح نص البحث لعرض جميع الفواتير.'}
              </p>
              {invoices.length === 0 && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={onGoToCashier}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0F766E] hover:bg-[#115E59] text-white text-sm font-bold transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إنشاء أول فاتورة</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="bg-[#F8FAFB] border-b border-[#E2E8EE] text-xs font-bold text-[#475569]">
                  <th className="py-3 px-4 whitespace-nowrap">رقم الفاتورة</th>
                  <th className="py-3 px-3 whitespace-nowrap">التاريخ والوقت</th>
                  <th className="py-3 px-3">الزبون والهاتف</th>
                  <th className="py-3 px-3">الأصناف</th>
                  <th className="py-3 px-3 text-center whitespace-nowrap">الدفع</th>
                  <th className="py-3 px-3 text-center whitespace-nowrap">الإجمالي (د.ع)</th>
                  <th className="py-3 px-4 text-center whitespace-nowrap">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF2F5] text-sm">
                {paginatedInvoices.map((inv) => {
                  const isConfirmingDelete = confirmDeleteId === inv.id;
                  const invTotalIqd = getInvoiceTotalIqd(inv);
                  return (
                    <tr
                      key={inv.id}
                      className="bg-white hover:bg-[#F8FAFB] transition-colors"
                    >
                      <td className="py-3 px-4 font-extrabold text-[#0F766E] tabular-nums whitespace-nowrap">
                        <span dir="ltr">{inv.serialNumber}</span>
                      </td>
                      <td className="py-3 px-3 text-xs font-semibold text-[#475569] whitespace-nowrap tabular-nums">
                        <div dir="ltr" className="text-right">
                          {inv.dateDisplay}
                        </div>
                        <div className="text-[#64748B]">{inv.timeDisplay}</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-[#1E293B]">
                          {inv.customerName || 'زبون نقدي'}
                        </div>
                        {inv.customerPhone && (
                          <div dir="ltr" className="text-xs text-[#64748B] text-right tabular-nums">
                            {inv.customerPhone}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 max-w-[240px]">
                        <div className="text-xs font-semibold text-[#334155] truncate">
                          {inv.items.map((it) => it.name || 'صنف').join('، ')}
                        </div>
                        <div className="text-[11px] text-[#64748B]">
                          {inv.items.length} {inv.items.length === 1 ? 'صنف' : 'أصناف'}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-center text-xs font-bold text-[#475569] whitespace-nowrap">
                        {getPaymentMethodLabel(inv.paymentMethod)}
                      </td>
                      <td className="py-3 px-3 text-center font-extrabold text-[#1E293B] tabular-nums whitespace-nowrap">
                        {formatIqd(invTotalIqd)}{' '}
                        <span className="text-xs font-semibold text-[#64748B]">د.ع</span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {isConfirmingDelete ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <span className="text-xs font-bold text-[#BE123C] flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              حذف؟
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteInvoice(inv.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-2 py-1 rounded-md bg-[#BE123C] text-white text-xs font-bold hover:bg-[#9F1239] cursor-pointer"
                              title="تأكيد الحذف"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2 py-1 rounded-md bg-[#F1F5F7] text-[#334155] text-xs font-bold hover:bg-[#E2E8EE] cursor-pointer"
                              title="تراجع"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onLoadInvoice(inv, false)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#F1F5F7] hover:bg-[#E2E8EE] text-[#1E293B] text-xs font-bold transition-colors cursor-pointer"
                              title="فتح الفاتورة في نقطة البيع"
                            >
                              <Eye className="w-3.5 h-3.5 text-[#475569]" />
                              <span>عرض</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onLoadInvoice(inv, true)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0F766E] hover:bg-[#115E59] text-white text-xs font-bold transition-colors cursor-pointer"
                              title="إعادة طباعة الفاتورة"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>طباعة</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(inv.id)}
                              className="p-1.5 rounded-lg text-[#94A3B8] hover:text-[#BE123C] hover:bg-[#FFF1F2] transition-colors cursor-pointer"
                              title="حذف الفاتورة"
                              aria-label="حذف الفاتورة"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination Footer */}
        {!isLoading && filteredInvoices.length > 0 && (
          <div className="px-5 py-3.5 bg-[#F8FAFB] border-t border-[#E2E8EE] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 text-xs font-bold text-[#475569] tabular-nums">
              <span>
                عرض {rangeStart} – {rangeEnd} من أصل {filteredInvoices.length.toLocaleString('en-US')} فاتورة
              </span>
              <span className="text-[#CBD5E1]" aria-hidden="true">|</span>
              <label className="inline-flex items-center gap-1.5">
                <span>لكل صفحة:</span>
                <select
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                  className="px-2 py-1 rounded-md border border-[#CBD5E1] bg-white text-[#1E293B] font-bold text-xs focus:outline-none focus:border-[#0F766E] cursor-pointer"
                >
                  {PAGE_SIZE_OPTIONS.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {totalPages > 1 && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={safePage === 1}
                  onClick={() => goToPage(1)}
                  className="p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#334155] hover:bg-[#F1F5F7] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة الأولى"
                  aria-label="الصفحة الأولى"
                >
                  <ChevronsRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={safePage === 1}
                  onClick={() => goToPage(safePage - 1)}
                  className="p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#334155] hover:bg-[#F1F5F7] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة السابقة"
                  aria-label="الصفحة السابقة"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {pageNumbers.map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => goToPage(num)}
                    className={`min-w-[32px] h-8 px-2 rounded-lg text-xs font-extrabold tabular-nums transition-colors cursor-pointer ${
                      num === safePage
                        ? 'bg-[#0F766E] text-white border border-[#0F766E]'
                        : 'bg-white text-[#334155] border border-[#CBD5E1] hover:bg-[#F1F5F7]'
                    }`}
                  >
                    {num}
                  </button>
                ))}

                <button
                  type="button"
                  disabled={safePage === totalPages}
                  onClick={() => goToPage(safePage + 1)}
                  className="p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#334155] hover:bg-[#F1F5F7] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة التالية"
                  aria-label="الصفحة التالية"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={safePage === totalPages}
                  onClick={() => goToPage(totalPages)}
                  className="p-1.5 rounded-lg border border-[#CBD5E1] bg-white text-[#334155] hover:bg-[#F1F5F7] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة الأخيرة"
                  aria-label="الصفحة الأخيرة"
                >
                  <ChevronsLeft className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
