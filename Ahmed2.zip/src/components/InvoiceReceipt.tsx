import React, { useState } from 'react';
import { AppSettings, InvoiceItem, PaymentMethod } from '../types';
import {
  FIXED_BANNER_IMAGE,
  FIXED_SHOP_ADDRESS,
  FIXED_SHOP_PHONE,
  formatIqd,
  getPaymentMethodLabel,
} from '../utils/storage';
import { numberToArabicIqdWords } from '../utils/arabicTafqeet';

export interface InvoiceReceiptProps {
  settings: AppSettings;
  serialNumber: string;
  dateDisplay: string;
  timeDisplay: string;
  customerName: string;
  customerPhone: string;
  customerNotes: string;
  items: InvoiceItem[];
  paymentMethod: PaymentMethod;
  totalIqd: number;
  /** When true (PrintPreviewModal), renders each A4 sheet with realistic paper shadow & page labels */
  previewMode?: boolean;
}

const SINGLE_PAGE_MAX = 20;
const FIRST_PAGE_CONTINUATION_MAX = 22;
const MIDDLE_PAGE_MAX = 26;
const LAST_PAGE_MAX = 20;

export interface InvoicePageChunk {
  items: InvoiceItem[];
  startIndex: number;
  pageNumber: number;
  totalPages: number;
}

/**
 * Splits items cleanly across physical A4 Portrait pages:
 * - Up to 20 items: 1 single A4 page (with auto-compact spacing for 15–20 items).
 * - 21+ items: Clean multi-page A4 sheets with repeated table headers, continuation
 *   bars, and totals/signatures placed strictly at the bottom of the final page.
 */
export function splitItemsIntoA4Pages(items: InvoiceItem[]): InvoicePageChunk[] {
  if (items.length <= SINGLE_PAGE_MAX) {
    return [
      {
        items,
        startIndex: 0,
        pageNumber: 1,
        totalPages: 1,
      },
    ];
  }

  const rawPages: { items: InvoiceItem[]; startIndex: number }[] = [];
  let cursor = 0;

  while (cursor < items.length) {
    const remaining = items.length - cursor;
    const isFirst = rawPages.length === 0;

    if (!isFirst && remaining <= LAST_PAGE_MAX) {
      rawPages.push({ items: items.slice(cursor), startIndex: cursor });
      break;
    }

    let take: number;
    if (isFirst) {
      take =
        remaining <= FIRST_PAGE_CONTINUATION_MAX
          ? Math.min(18, remaining - 1)
          : FIRST_PAGE_CONTINUATION_MAX;
    } else if (remaining <= MIDDLE_PAGE_MAX) {
      take = Math.min(18, remaining - 1);
    } else {
      take = MIDDLE_PAGE_MAX;
    }

    rawPages.push({ items: items.slice(cursor, cursor + take), startIndex: cursor });
    cursor += take;
  }

  const totalPages = rawPages.length;
  return rawPages.map((chunk, idx) => ({
    ...chunk,
    pageNumber: idx + 1,
    totalPages,
  }));
}

export function getActiveReceiptItems(items: InvoiceItem[]): InvoiceItem[] {
  const populated = items.filter(
    (it) => it.name.trim() !== '' || it.unitPrice > 0 || it.notes.trim() !== ''
  );
  return populated.length > 0 ? populated : items;
}

/**
 * Print-shop calibrated A4 Portrait commercial invoice:
 * - Full-sheet A4 Portrait height & vertical balance (footer anchored at bottom).
 * - Zero-crop full banner, clean un-duplicated metadata, zero visual dash noise.
 * - Auto-compact density for 15–20 items on 1 page; multi-page A4 for 21+ items.
 */
export const InvoiceReceipt: React.FC<InvoiceReceiptProps> = ({
  settings,
  serialNumber,
  dateDisplay,
  timeDisplay,
  customerName,
  customerPhone,
  customerNotes,
  items,
  paymentMethod,
  totalIqd,
  previewMode = false,
}) => {
  const [bannerImgError, setBannerImgError] = useState(false);
  const activeBannerSrc = settings.bannerImage || FIXED_BANNER_IMAGE;
  const shopAddress = FIXED_SHOP_ADDRESS;
  const shopPhone = FIXED_SHOP_PHONE;
  const activeItems = getActiveReceiptItems(items);
  const pages = splitItemsIntoA4Pages(activeItems);
  const totalPages = pages.length;

  // Compact row padding activates at 14+ items or multi-page so up to 20 items fit comfortably on 1 A4 page
  const isCompact = activeItems.length >= 14 || totalPages > 1;

  const totalPieces = activeItems.reduce(
    (sum, it) => sum + (Number.isFinite(it.quantity) ? it.quantity : 0),
    0
  );
  const tafqeetText = numberToArabicIqdWords(totalIqd);

  return (
    <div dir="rtl" className={previewMode ? 'w-full space-y-6' : 'w-full'}>
      {pages.map((page) => {
        const isFirstPage = page.pageNumber === 1;
        const isLastPage = page.pageNumber === totalPages;

        // Fill ruled ledger lines on invoices up to 13 items so the A4 sheet looks balanced & authentic
        const minRuledRows = totalPages === 1 && !isCompact ? 13 : 0;
        const blankRowCount = Math.max(0, minRuledRows - page.items.length);

        const cellPad = isCompact ? 'py-[4px]' : 'py-2';
        const tableText = isCompact ? 'text-[11px] leading-[1.35]' : 'text-xs sm:text-[13px]';

        return (
          <div key={page.pageNumber} className="invoice-a4-page w-full">
            {previewMode && totalPages > 1 && (
              <div className="text-xs font-bold text-[#475569] mb-2 text-center tabular-nums">
                صفحة {page.pageNumber} من {totalPages}
              </div>
            )}

            <article
              className={`w-full bg-white text-[#0E2240] select-text flex flex-col print:p-0 print:shadow-none print:border-0 ${
                previewMode
                  ? 'p-4 sm:p-5 shadow-[0_14px_36px_rgba(15,23,42,0.18)] border border-[#CBD5E1] min-h-[278mm]'
                  : 'p-0 min-h-[270mm]'
              }`}
            >
              {/* Formal Double-Rule Stationery Frame stretched to full A4 sheet height */}
              <div className="border-2 border-[#0E2A52] p-[2px] bg-white flex-1 flex flex-col">
                <div className="border border-[#B7C8DC] flex-1 flex flex-col">
                  {/* =========================================================
                      1. HEADER (Full Banner on Page 1; Clean Continuation Bar on Page 2+)
                     ========================================================= */}
                  {isFirstPage ? (
                    <header className="relative bg-white overflow-hidden print-avoid-break">
                      {activeBannerSrc && !bannerImgError ? (
                        /* Official Saved Banner — Clean Edge-to-Edge, Zero Extra Top Strip */
                        <div>
                          <div className="w-full bg-white border-b border-[#CBD5E1] flex items-center justify-center">
                            <img
                              src={activeBannerSrc}
                              alt="أحمد القيسي للإطارات والبطاريات"
                              referrerPolicy="no-referrer"
                              onError={() => setBannerImgError(true)}
                              className="w-full h-auto object-contain block"
                            />
                          </div>
                          {/* Clean Non-Redundant Document Strip */}
                          <div className="px-4 py-2 bg-[#F8FAFC] border-b-2 border-[#0E2A52] flex flex-wrap items-center justify-between gap-2 text-xs">
                            <div className="font-black text-[#0E2A52] text-[13px] tracking-tight">
                              فاتورة مبيعات
                            </div>
                            <div className="flex flex-wrap items-center gap-3.5 tabular-nums font-bold text-[#1E293B]">
                              <span>
                                رقم الفاتورة:{' '}
                                <strong dir="ltr" className="text-[#C8102E] font-black">
                                  {serialNumber}
                                </strong>
                              </span>
                              <span className="text-[#CBD5E1]" aria-hidden="true">
                                |
                              </span>
                              <span>
                                التاريخ: <strong dir="ltr">{dateDisplay}</strong>
                              </span>
                              <span className="text-[#CBD5E1]" aria-hidden="true">
                                |
                              </span>
                              <span>
                                الوقت: <strong>{timeDisplay}</strong>
                              </span>
                              {totalPages > 1 && (
                                <>
                                  <span className="text-[#CBD5E1]" aria-hidden="true">
                                    |
                                  </span>
                                  <span className="text-[#0E2A52] font-extrabold">
                                    صفحة {page.pageNumber} من {totalPages}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      ) : (
                        /* Fallback Commercial Letterhead (if image ever fails to load) */
                        <div
                          className={`relative px-4 ${
                            isCompact ? 'py-2.5' : 'py-3.5'
                          } bg-[#F9FBFE] border-b-2 border-[#0E2A52]`}
                        >
                          <div className="relative z-10 grid grid-cols-12 items-center gap-2.5">
                            <div className="col-span-5 flex items-stretch gap-2.5">
                              <div className="w-1.5 bg-[#C8102E] shrink-0 rounded-xs" />
                              <div className="flex flex-col justify-center">
                                <h1 className="font-black text-[#C8102E] leading-[1.06] tracking-tight text-[1.75rem]">
                                  أحمد القيسي
                                </h1>
                                <div className="font-extrabold text-[#0E2A52] leading-tight mt-0.5 text-[1rem]">
                                  للإطارات والبطاريات
                                </div>
                                <div className="mt-1 inline-flex items-center gap-1.5 text-[10px] font-bold text-[#4A5E7A]">
                                  <span>جودة</span>
                                  <span className="text-[#C99612]">◆</span>
                                  <span>ثقة</span>
                                  <span className="text-[#C99612]">◆</span>
                                  <span>أسعار مناسبة</span>
                                </div>
                              </div>
                            </div>

                            <div className="col-span-3 flex flex-col items-center justify-center text-center">
                              <div className="px-3 py-1.5 border-y-2 border-[#0E2A52] bg-white">
                                <div className="font-black text-[#0E2A52] text-base leading-tight whitespace-nowrap">
                                  فاتورة مبيعات
                                </div>
                                <div className="text-[8.5px] font-bold tracking-[0.16em] text-[#6B7F99] uppercase mt-0.5 whitespace-nowrap">
                                  SALES INVOICE
                                </div>
                              </div>
                              {totalPages > 1 && (
                                <div className="mt-1 text-[10px] font-extrabold text-[#3D5575] tabular-nums">
                                  صفحة {page.pageNumber} من {totalPages}
                                </div>
                              )}
                            </div>

                            <div className="col-span-4">
                              <div className="border border-[#B7C8DC] bg-white text-xs">
                                <div className="grid grid-cols-2 border-b border-[#D5E1EE]">
                                  <div className="px-2 py-0.5 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE]">
                                    رقم الفاتورة
                                  </div>
                                  <div
                                    dir="ltr"
                                    className="px-2 py-0.5 font-black text-[#C8102E] text-center tabular-nums"
                                  >
                                    {serialNumber}
                                  </div>
                                </div>
                                <div className="grid grid-cols-2 border-b border-[#D5E1EE]">
                                  <div className="px-2 py-0.5 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE]">
                                    التاريخ
                                  </div>
                                  <div
                                    dir="ltr"
                                    className="px-2 py-0.5 font-extrabold text-[#0E2A52] text-center tabular-nums"
                                  >
                                    {dateDisplay}
                                  </div>
                                </div>
                                <div className="grid grid-cols-2">
                                  <div className="px-2 py-0.5 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE]">
                                    الوقت
                                  </div>
                                  <div className="px-2 py-0.5 font-bold text-[#0E2A52] text-center tabular-nums">
                                    {timeDisplay}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </header>
                  ) : (
                    /* Compact Continuation Header for Page 2+ */
                    <header className="bg-[#F8FAFC] border-b-2 border-[#0E2A52] print-avoid-break">
                      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-[#C8102E]">أحمد القيسي</span>
                          <span className="font-extrabold text-[#0E2A52]">للإطارات والبطاريات</span>
                          <span className="text-[#94A3B8]">|</span>
                          <span className="font-bold text-[#3D5575]">
                            تابع فاتورة{' '}
                            <strong dir="ltr" className="text-[#C8102E] font-black">
                              {serialNumber}
                            </strong>
                          </span>
                        </div>
                        <div className="flex items-center gap-3 font-bold text-[#1B355B] tabular-nums">
                          <span>الزبون: {customerName.trim() || 'زبون نقدي'}</span>
                          <span className="text-[#94A3B8]">|</span>
                          <span dir="ltr">{dateDisplay}</span>
                          <span className="text-[#94A3B8]">|</span>
                          <span className="font-extrabold text-[#0E2A52]">
                            صفحة {page.pageNumber} من {totalPages}
                          </span>
                        </div>
                      </div>
                    </header>
                  )}

                  {/* =========================================================
                      2. CUSTOMER INFORMATION LEDGER BAR (Page 1 only, pen-friendly blanks)
                     ========================================================= */}
                  {isFirstPage && (
                    <section
                      className={`px-4 print-avoid-break ${
                        isCompact ? 'pt-2 pb-1.5' : 'pt-3 pb-2.5'
                      }`}
                    >
                      <div
                        className={`grid grid-cols-12 border border-[#CBD5E1] bg-[#F8FAFD] ${
                          isCompact ? 'text-[11.5px]' : 'text-xs sm:text-[13px]'
                        }`}
                      >
                        <div
                          className={`col-span-5 flex items-center gap-1.5 px-2.5 border-l border-[#CBD5E1] min-w-0 ${
                            isCompact ? 'py-1.5' : 'py-2'
                          }`}
                        >
                          <span className="font-bold text-[#475569] whitespace-nowrap shrink-0">
                            السيد / الزبون :
                          </span>
                          <span className="font-extrabold text-[#0E2240] truncate">
                            {customerName.trim() || 'زبون نقدي'}
                          </span>
                        </div>

                        <div
                          className={`col-span-3 flex items-center gap-1.5 px-2.5 border-l border-[#CBD5E1] min-w-0 ${
                            isCompact ? 'py-1.5' : 'py-2'
                          }`}
                        >
                          <span className="font-bold text-[#475569] whitespace-nowrap shrink-0">
                            الهاتف :
                          </span>
                          <span
                            dir="ltr"
                            className="font-bold text-[#0E2240] tabular-nums truncate"
                          >
                            {customerPhone.trim()}
                          </span>
                        </div>

                        <div
                          className={`col-span-4 flex items-center gap-1.5 px-2.5 min-w-0 ${
                            isCompact ? 'py-1.5' : 'py-2'
                          }`}
                        >
                          <span className="font-bold text-[#475569] whitespace-nowrap shrink-0">
                            ملاحظات :
                          </span>
                          <span className="font-bold text-[#0E2240] truncate">
                            {customerNotes.trim()}
                          </span>
                        </div>
                      </div>
                    </section>
                  )}

                  {/* =========================================================
                      3. MAIN ITEMS LEDGER TABLE (Grows cleanly to fill A4 body)
                     ========================================================= */}
                  <section className={`px-4 flex-1 ${!isFirstPage ? 'pt-3' : ''}`}>
                    <table className={`w-full border-collapse border border-[#0E2A52] ${tableText}`}>
                      <thead>
                        <tr className="bg-[#0E2A52] text-white border-b-2 border-[#D4A017]">
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-1.5 font-extrabold border-l border-white/20 text-center w-[34px]`}
                          >
                            ت
                          </th>
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-3 font-extrabold border-l border-white/20 text-right`}
                          >
                            التفاصيل / الصنف
                          </th>
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-1.5 font-extrabold border-l border-white/20 text-center w-[54px]`}
                          >
                            الكمية
                          </th>
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-2 font-extrabold border-l border-white/20 text-center w-[108px] whitespace-nowrap`}
                          >
                            سعر الوحدة (د.ع)
                          </th>
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-1.5 font-extrabold border-l border-white/20 text-center w-[78px]`}
                          >
                            الضمان
                          </th>
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-2 font-extrabold border-l border-white/20 text-center w-[114px] whitespace-nowrap`}
                          >
                            المبلغ الكلي (د.ع)
                          </th>
                          <th
                            className={`${
                              isCompact ? 'py-1.5' : 'py-2'
                            } px-2 font-extrabold text-center w-[98px]`}
                          >
                            ملاحظات
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {page.items.map((item, idx) => {
                          const globalIdx = page.startIndex + idx;
                          const qty = Number.isFinite(item.quantity) ? item.quantity : 0;
                          const unitPrice = Number.isFinite(item.unitPrice) ? item.unitPrice : 0;
                          const rowTotal = Math.round(qty * unitPrice);

                          return (
                            <tr
                              key={item.id}
                              className={`${
                                idx % 2 === 1 ? 'bg-[#F8FAFC]' : 'bg-white'
                              } border-b border-[#CBD5E1]`}
                            >
                              <td
                                className={`${cellPad} px-1.5 text-center font-bold text-[#475569] border-l border-[#CBD5E1] tabular-nums`}
                              >
                                {globalIdx + 1}
                              </td>
                              <td
                                className={`${cellPad} px-3 text-right font-extrabold text-[#0E2240] border-l border-[#CBD5E1]`}
                              >
                                {item.name.trim()}
                              </td>
                              <td
                                className={`${cellPad} px-1.5 text-center font-extrabold text-[#0E2240] border-l border-[#CBD5E1] tabular-nums`}
                              >
                                {qty}
                              </td>
                              <td
                                className={`${cellPad} px-2 text-center font-bold text-[#0E2240] border-l border-[#CBD5E1] tabular-nums`}
                              >
                                {formatIqd(unitPrice)}
                              </td>
                              <td
                                className={`${cellPad} px-1.5 text-center font-bold text-[#1E3A5F] border-l border-[#CBD5E1]`}
                              >
                                {item.warranty.trim()}
                              </td>
                              <td
                                className={`${cellPad} px-2 text-center font-black text-[#0E2A52] border-l border-[#CBD5E1] tabular-nums`}
                              >
                                {formatIqd(rowTotal)}
                              </td>
                              <td
                                className={`${cellPad} px-2 text-center font-semibold text-[#475569]`}
                              >
                                {item.notes.trim()}
                              </td>
                            </tr>
                          );
                        })}

                        {/* Clean Ruled Blank Ledger Lines on short single-page invoices */}
                        {Array.from({ length: blankRowCount }).map((_, idx) => {
                          const rowIndex = page.items.length + idx;
                          return (
                            <tr
                              key={`blank-${idx}`}
                              className={`${
                                rowIndex % 2 === 1 ? 'bg-[#FAFCFF]' : 'bg-white'
                              } border-b border-[#DDE5EE] h-[29px]`}
                            >
                              <td className="border-l border-[#DDE5EE]" />
                              <td className="border-l border-[#DDE5EE]" />
                              <td className="border-l border-[#DDE5EE]" />
                              <td className="border-l border-[#DDE5EE]" />
                              <td className="border-l border-[#DDE5EE]" />
                              <td className="border-l border-[#DDE5EE]" />
                              <td />
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </section>

                  {/* =========================================================
                      4 & 5. CONTINUATION FOOTER OR ANCHORED BOTTOM TOTALS & SIGNATURES
                     ========================================================= */}
                  {!isLastPage ? (
                    <footer className="mt-auto px-4 py-2.5 border-t border-[#CBD5E1] bg-[#F8FAFD] flex items-center justify-between text-xs font-bold text-[#3D5575] print-avoid-break">
                      <span>
                        يُتبع في الصفحة التالية (صفحة {page.pageNumber + 1} من {totalPages})...
                      </span>
                      <span className="tabular-nums text-[#0E2A52]">
                        فاتورة رقم {serialNumber}
                      </span>
                    </footer>
                  ) : (
                    <div className="mt-auto print-avoid-break">
                      {/* TOTALS, ARABIC TAFQEET & COMMERCIAL TERMS */}
                      <section
                        className={`px-4 ${
                          isCompact ? 'pt-2.5 pb-2' : 'pt-3.5 pb-3.5'
                        } grid grid-cols-12 gap-3 items-stretch`}
                      >
                        {/* RIGHT (7 cols): Amount in Arabic Words (التفقيط) + Warranty Terms */}
                        <div className="col-span-7 flex flex-col justify-between gap-2">
                          <div
                            className={`border border-[#CBD5E1] bg-[#F8FAFD] px-3.5 ${
                              isCompact ? 'py-2' : 'py-2.5'
                            }`}
                          >
                            <div className="text-[10.5px] font-bold text-[#475569] mb-0.5">
                              المبلغ كتابةً :
                            </div>
                            <div
                              className={`font-extrabold text-[#0E2A52] leading-relaxed ${
                                isCompact ? 'text-xs' : 'text-[13px]'
                              }`}
                            >
                              {tafqeetText}
                            </div>
                          </div>

                          <div
                            className={`border border-[#DCE4EE] bg-white px-3.5 text-[#475569] leading-relaxed ${
                              isCompact ? 'py-1.5 text-[10.5px]' : 'py-2 text-[11px]'
                            }`}
                          >
                            <span className="font-extrabold text-[#0E2A52]">ملاحظة الضمان: </span>
                            <span>
                              يُرجى الاحتفاظ بهذا الوصل لمراجعة الضمان عند الحاجة؛ يشمل الضمان
                              العيوب المصنعية فقط وفق المدة المثبتة أعلاه.
                            </span>
                          </div>
                        </div>

                        {/* LEFT (5 cols): Accounting Summary Table */}
                        <div className="col-span-5 flex flex-col justify-between border border-[#0E2A52] bg-white">
                          <div
                            className={`divide-y divide-[#D5E1EE] ${
                              isCompact ? 'text-[11px]' : 'text-xs'
                            }`}
                          >
                            <div
                              className={`flex items-center justify-between px-3 ${
                                isCompact ? 'py-1.5' : 'py-2'
                              }`}
                            >
                              <span className="font-bold text-[#475569]">عدد الأصناف / القطع</span>
                              <span className="font-extrabold text-[#0E2240] tabular-nums">
                                {activeItems.length} صنف ({totalPieces} قطعة)
                              </span>
                            </div>
                            <div
                              className={`flex items-center justify-between px-3 ${
                                isCompact ? 'py-1.5' : 'py-2'
                              }`}
                            >
                              <span className="font-bold text-[#475569]">طريقة التسديد</span>
                              <span className="font-extrabold text-[#0E2240]">
                                {getPaymentMethodLabel(paymentMethod)}
                              </span>
                            </div>
                          </div>

                          {/* Grand Total Bar — High-Contrast Authoritative Figure */}
                          <div
                            className={`bg-[#0E2A52] text-white px-3.5 border-t-2 border-[#D4A017] flex items-center justify-between gap-2 ${
                              isCompact ? 'py-2' : 'py-2.5'
                            }`}
                          >
                            <span className="font-extrabold whitespace-nowrap text-sm">
                              المجموع الكلي
                            </span>
                            <div className="text-left tabular-nums whitespace-nowrap flex items-baseline gap-1.5">
                              <span
                                className={`font-black text-[#FFD000] ${
                                  isCompact ? 'text-xl' : 'text-2xl'
                                }`}
                              >
                                {formatIqd(totalIqd)}
                              </span>
                              <span className="text-xs font-extrabold text-[#F5CC27]">د.ع</span>
                            </div>
                          </div>
                        </div>
                      </section>

                      {/* SIGNATURES (Spacious for Stamp & Pen) & OFFICIAL FOOTER */}
                      <footer>
                        <div
                          className={`px-8 grid grid-cols-2 gap-10 text-xs ${
                            isCompact ? 'pt-3 pb-3' : 'pt-4 pb-4'
                          }`}
                        >
                          <div className="text-center">
                            <div className="font-bold text-[#334155]">توقيع المستلم (الزبون)</div>
                            <div
                              className={`mx-auto w-52 border-b border-[#64748B] ${
                                isCompact ? 'mt-6' : 'mt-8'
                              }`}
                            />
                          </div>
                          <div className="text-center">
                            <div className="font-bold text-[#334155]">توقيع وختم البائع</div>
                            <div
                              className={`mx-auto w-52 border-b border-[#64748B] ${
                                isCompact ? 'mt-6' : 'mt-8'
                              }`}
                            />
                          </div>
                        </div>

                        <div className="bg-[#0E2A52] text-white border-t-2 border-[#D4A017] px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-3">
                          <div className="font-extrabold text-[#FFD000]">
                            شكراً لثقتكم — نتشرف بخدمتكم دائماً
                          </div>

                          <div className="flex flex-wrap items-center gap-2.5 font-bold text-white/95">
                            <span>العنوان: {shopAddress}</span>
                            <span className="text-[#D4A017]" aria-hidden="true">
                              |
                            </span>
                            <span>
                              الهاتف:{' '}
                              <span dir="ltr" className="tabular-nums font-extrabold">
                                {shopPhone}
                              </span>
                            </span>
                          </div>
                        </div>
                      </footer>
                    </div>
                  )}
                </div>
              </div>
            </article>
          </div>
        );
      })}
    </div>
  );
};
