import React, { useEffect } from 'react';
import {
  ShoppingBag,
  ClipboardList,
  Settings,
  Eye,
  FilePlus2,
  X,
  Printer,
} from 'lucide-react';

export type ActiveTab = 'cashier' | 'inventory' | 'settings';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  savedCount: number;
  hasActiveSavedInvoice: boolean;
  onNewInvoice: () => void;
  onOpenPreview: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  savedCount,
  hasActiveSavedInvoice,
  onNewInvoice,
  onOpenPreview,
  isMobileOpen,
  onCloseMobile,
}) => {
  // Close mobile drawer on Escape
  useEffect(() => {
    if (!isMobileOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCloseMobile();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMobileOpen, onCloseMobile]);

  const handleNavClick = (tab: ActiveTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  const navItems: {
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    count?: number;
  }[] = [
    { id: 'cashier', label: 'نقطة البيع', icon: ShoppingBag },
    { id: 'inventory', label: 'سجل الفواتير والجرد', icon: ClipboardList, count: savedCount },
    { id: 'settings', label: 'إعدادات الطباعة', icon: Settings },
  ];

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#1C252C] text-[#E6EDF2] select-none">
      {/* Brand Lockup */}
      <div className="px-5 py-5 border-b border-white/[0.08] flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="text-lg font-extrabold text-white tracking-tight leading-snug truncate">
            أحمد القيسي
          </div>
          <div className="text-xs font-semibold text-[#90A4B4] mt-0.5 truncate">
            للإطارات والبطاريات
          </div>
        </div>

        {/* Mobile drawer close button */}
        <button
          type="button"
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 rounded-lg text-[#90A4B4] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="إغلاق القائمة"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Primary Navigation */}
      <nav aria-label="القائمة الرئيسية" className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-bold text-[#7C91A1]">القائمة الرئيسية</div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavClick(item.id)}
              aria-current={isActive ? 'page' : undefined}
              className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-[#0F766E] text-white shadow-xs'
                  : 'text-[#C2D0DB] hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`w-[18px] h-[18px] shrink-0 ${
                    isActive ? 'text-[#CCFBF1]' : 'text-[#899FAF]'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </span>

              {typeof item.count === 'number' && item.count > 0 && (
                <span
                  className={`text-xs font-bold tabular-nums shrink-0 ${
                    isActive ? 'text-[#CCFBF1]' : 'text-[#899FAF]'
                  }`}
                >
                  {item.count.toLocaleString('en-US')}
                </span>
              )}
            </button>
          );
        })}

        {/* Quick Actions Section */}
        <div className="pt-5 mt-4 border-t border-white/[0.08] space-y-1">
          <div className="px-3 pb-2 text-[11px] font-bold text-[#7C91A1]">وصول سريع</div>

          <button
            type="button"
            onClick={() => {
              onOpenPreview();
              onCloseMobile();
            }}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-semibold text-[#C2D0DB] hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <Eye className="w-[18px] h-[18px] text-[#899FAF] shrink-0" />
            <span>معاينة الوصل الحالي</span>
          </button>

          {(hasActiveSavedInvoice || activeTab !== 'cashier') && (
            <button
              type="button"
              onClick={() => {
                onNewInvoice();
                onCloseMobile();
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-semibold text-[#C2D0DB] hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              <FilePlus2 className="w-[18px] h-[18px] text-[#899FAF] shrink-0" />
              <span>إنشاء فاتورة جديدة</span>
            </button>
          )}
        </div>
      </nav>

      {/* Quiet Paper Format & Local Storage Footer */}
      <div className="px-5 py-3.5 border-t border-white/[0.08] text-xs text-[#899FAF] space-y-1">
        <div className="flex items-center gap-2 font-semibold text-[#B4C4D0]">
          <Printer className="w-3.5 h-3.5 text-[#5EEAD4] shrink-0" />
          <span>مقاس الورق: A4 عمودي</span>
        </div>
        <div className="text-[11px] text-[#7C91A1]">حفظ محلي آمن · الدينار العراقي</div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Right Sidebar (RTL) */}
      <aside
        aria-label="الشريط الجانبي"
        className="hidden lg:flex lg:flex-col lg:w-[248px] lg:shrink-0 lg:sticky lg:top-0 lg:h-screen border-l border-[#2A3741]"
      >
        {sidebarContent}
      </aside>

      {/* Mobile / Tablet Slide-Over Drawer */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-50 lg:hidden flex bg-[rgba(15,23,42,0.5)]"
          onClick={onCloseMobile}
          role="dialog"
          aria-modal="true"
          aria-label="القائمة الجانبية"
        >
          <div
            className="w-[268px] max-w-[82vw] h-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
