import React, { useEffect } from 'react';
import { X, Printer, FileText } from 'lucide-react';
import { AppSettings, InvoiceItem, PaymentMethod } from '../types';
import {
  InvoiceReceipt,
  getActiveReceiptItems,
  splitItemsIntoA4Pages,
} from './InvoiceReceipt';

interface PrintPreviewModalProps {
  isOpen: boolean;
  isPrinting?: boolean;
  onClose: () => void;
  onConfirmPrint: () => void;
  settings: AppSettings;
  serialNumber: string;
  dateDisplay: string;
  timeDisplay: string;
  customerName: string;
  customerPhone: string;
  customerNotes: string;
  items: InvoiceItem[];
  paymentMethod: PaymentMethod;
  totalIqd: number;
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({
  isOpen,
  isPrinting = false,
  onClose,
  onConfirmPrint,
  settings,
  serialNumber,
  dateDisplay,
  timeDisplay,
  customerName,
  customerPhone,
  customerNotes,
  items,
  paymentMethod,
  totalIqd,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const activeItems = getActiveReceiptItems(items);
  const totalPages = splitItemsIntoA4Pages(activeItems).length;
  const pageCountLabel =
    totalPages === 1
      ? 'صفحة واحدة'
      : totalPages === 2
      ? 'صفحتان'
      : `${totalPages} صفحات`;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-[rgba(15,23,42,0.65)] p-2 sm:p-4 print:hidden"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="print-preview-title"
    >
      <div
        className="w-full max-w-5xl mx-auto flex-1 max-h-[95vh] bg-[#E8EEF2] rounded-xl shadow-2xl border border-[#CBD5E1] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Preview Toolbar */}
        <div className="px-4 sm:px-6 py-3 bg-[#1C252C] text-white flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-[#5EEAD4] shrink-0" />
            <h2 id="print-preview-title" className="text-base sm:text-lg font-extrabold">
              معاينة الوصل قبل الطباعة
            </h2>
            <span dir="ltr" className="text-xs font-extrabold text-[#99F6E4] tabular-nums">
              · {serialNumber}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-xs font-bold text-[#B4C4D0] whitespace-nowrap">
              A4 عمودي · {pageCountLabel}
            </span>

            {/* Print Now CTA */}
            <button
              type="button"
              disabled={isPrinting}
              onClick={onConfirmPrint}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-[#0F766E] hover:bg-[#115E59] disabled:opacity-60 disabled:cursor-not-allowed text-white font-extrabold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <Printer className="w-4 h-4" />
              <span>{isPrinting ? 'جارٍ الإرسال للطابعة...' : 'طباعة الآن'}</span>
            </button>

            {/* Close / Back to Edit */}
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white/10 hover:bg-white/18 text-white font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <X className="w-4 h-4" />
              <span>رجوع</span>
            </button>
          </div>
        </div>

        {/* Paper Preview Stage */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-7 flex flex-col items-center">
          <div className="text-xs font-bold text-[#475569] mb-4 text-center tabular-nums">
            معاينة مطابقة لورق A4 عمودي (210 × 297 ملم) — {pageCountLabel} ({activeItems.length}{' '}
            {activeItems.length === 1 ? 'صنف' : 'أصناف'})
          </div>

          {/* Realistic A4 Paper Sheet(s) */}
          <div className="w-full max-w-[794px]">
            <InvoiceReceipt
              previewMode
              settings={settings}
              serialNumber={serialNumber}
              dateDisplay={dateDisplay}
              timeDisplay={timeDisplay}
              customerName={customerName}
              customerPhone={customerPhone}
              customerNotes={customerNotes}
              items={items}
              paymentMethod={paymentMethod}
              totalIqd={totalIqd}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
