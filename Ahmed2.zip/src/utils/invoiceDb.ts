import { Invoice } from '../types';
import {
  getLastSerial,
  loadInvoices as loadLegacyLocalInvoices,
  saveInvoices as saveLegacyLocalInvoices,
  saveLastSerial,
} from './storage';

const DB_NAME = 'AlQaisiPOS_DB';
const DB_VERSION = 1;
const STORE_INVOICES = 'invoices';
const STORE_META = 'meta';
const LEGACY_INVOICES_KEY = 'alqaisi_pos_invoices_v1';

interface MetaRecord {
  key: string;
  value: unknown;
}

let dbPromise: Promise<IDBDatabase | null> | null = null;

function isIndexedDbSupported(): boolean {
  try {
    return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
  } catch {
    return false;
  }
}

function openDatabase(): Promise<IDBDatabase | null> {
  if (!isIndexedDbSupported()) {
    return Promise.resolve(null);
  }
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve) => {
    try {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_INVOICES)) {
          const store = db.createObjectStore(STORE_INVOICES, { keyPath: 'id' });
          store.createIndex('numericSerial', 'numericSerial', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_META)) {
          db.createObjectStore(STORE_META, { keyPath: 'key' });
        }
      };

      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => {
          db.close();
          dbPromise = null;
        };
        resolve(db);
      };

      request.onerror = () => {
        dbPromise = null;
        resolve(null);
      };

      request.onblocked = () => {
        resolve(null);
      };
    } catch {
      dbPromise = null;
      resolve(null);
    }
  });

  return dbPromise;
}

function sortInvoicesDescending(list: Invoice[]): Invoice[] {
  return [...list].sort((a, b) => {
    const diff = (b.numericSerial || 0) - (a.numericSerial || 0);
    if (diff !== 0) return diff;
    return (b.createdAt || '').localeCompare(a.createdAt || '');
  });
}

function readAllFromStore(db: IDBDatabase): Promise<Invoice[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_INVOICES, 'readonly');
    const store = tx.objectStore(STORE_INVOICES);
    const req = store.getAll();
    req.onsuccess = () => resolve((req.result as Invoice[]) || []);
    req.onerror = () => reject(req.error);
  });
}

/**
 * Initializes IndexedDB, migrates any existing localStorage invoices automatically,
 * and returns all saved invoices sorted newest-first.
 */
export async function dbInitAndLoadInvoices(): Promise<Invoice[]> {
  const db = await openDatabase();
  const legacyList = loadLegacyLocalInvoices();

  if (!db) {
    return sortInvoicesDescending(legacyList);
  }

  try {
    let existing = await readAllFromStore(db);

    // One-time seamless migration from localStorage -> IndexedDB
    if (legacyList.length > 0) {
      const existingIds = new Set(existing.map((inv) => inv.id));
      const toMigrate = legacyList.filter((inv) => !existingIds.has(inv.id));

      if (toMigrate.length > 0) {
        await dbBulkPutInvoices(toMigrate);
        existing = [...existing, ...toMigrate];
      }

      // Clear legacy invoice array from localStorage so 5MB quota stays completely free
      try {
        localStorage.removeItem(LEGACY_INVOICES_KEY);
      } catch {
        // ignore storage errors
      }
    }

    const sorted = sortInvoicesDescending(existing);
    const maxSerial = sorted.reduce((m, i) => Math.max(m, i.numericSerial || 0), getLastSerial());
    if (maxSerial > 0) {
      saveLastSerial(maxSerial);
    }
    return sorted;
  } catch {
    return sortInvoicesDescending(legacyList);
  }
}

/** Saves or updates a single invoice in O(1) time inside IndexedDB. */
export async function dbPutInvoice(
  invoice: Invoice,
  fallbackFullList?: Invoice[]
): Promise<boolean> {
  const db = await openDatabase();
  if (!db) {
    return fallbackFullList ? saveLegacyLocalInvoices(fallbackFullList) : false;
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_INVOICES, STORE_META], 'readwrite');
      tx.objectStore(STORE_INVOICES).put(invoice);

      const nextMax = Math.max(getLastSerial(), invoice.numericSerial || 0);
      tx.objectStore(STORE_META).put({ key: 'lastSerial', value: nextMax } satisfies MetaRecord);

      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/** Deletes a single invoice by ID inside IndexedDB. */
export async function dbDeleteInvoice(
  id: string,
  fallbackRemainingList?: Invoice[]
): Promise<boolean> {
  const db = await openDatabase();
  if (!db) {
    return fallbackRemainingList ? saveLegacyLocalInvoices(fallbackRemainingList) : false;
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_INVOICES, 'readwrite');
      tx.objectStore(STORE_INVOICES).delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/** Imports/updates many invoices in a single atomic IndexedDB transaction. */
export async function dbBulkPutInvoices(
  invoices: Invoice[],
  fallbackMergedList?: Invoice[]
): Promise<boolean> {
  const db = await openDatabase();
  if (!db) {
    return fallbackMergedList ? saveLegacyLocalInvoices(fallbackMergedList) : false;
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_INVOICES, STORE_META], 'readwrite');
      const store = tx.objectStore(STORE_INVOICES);
      let maxSerial = getLastSerial();

      for (const inv of invoices) {
        store.put(inv);
        if ((inv.numericSerial || 0) > maxSerial) {
          maxSerial = inv.numericSerial;
        }
      }

      tx.objectStore(STORE_META).put({ key: 'lastSerial', value: maxSerial } satisfies MetaRecord);

      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/** Stores custom banner Data URL in IndexedDB so large images never fill localStorage. */
export async function dbSaveBannerImage(dataUrl: string | null): Promise<boolean> {
  const db = await openDatabase();
  if (!db) return false;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_META, 'readwrite');
      const store = tx.objectStore(STORE_META);
      if (dataUrl) {
        store.put({ key: 'bannerImage', value: dataUrl } satisfies MetaRecord);
      } else {
        store.delete('bannerImage');
      }
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/** Loads custom banner Data URL from IndexedDB. */
export async function dbLoadBannerImage(): Promise<string | null> {
  const db = await openDatabase();
  if (!db) return null;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_META, 'readonly');
      const req = tx.objectStore(STORE_META).get('bannerImage');
      req.onsuccess = () => {
        const record = req.result as MetaRecord | undefined;
        resolve(typeof record?.value === 'string' ? record.value : null);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}
