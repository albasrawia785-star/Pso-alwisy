const { app, BrowserWindow, ipcMain } = require('electron');
const os = require('os');
const path = require('path');

// Prevent blank GPU screens on Windows 7 / 8 / 8.1 (NT kernel < 10) with older display drivers
if (os.platform() === 'win32') {
  const majorKernel = Number.parseInt(os.release().split('.')[0] || '10', 10);
  if (Number.isFinite(majorKernel) && majorKernel < 10) {
    app.disableHardwareAcceleration();
  }
}

// Ensure only a single instance of the POS app runs at a time
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  app.quit();
}

let mainWindow = null;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 840,
    minWidth: 1024,
    minHeight: 680,
    title: 'أحمد القيسي للإطارات والبطاريات',
    backgroundColor: '#F5F7F8',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.once('ready-to-show', () => {
    if (mainWindow) {
      mainWindow.show();
    }
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  }
});

// Return installed OS printers (USB / Cable / Network)
ipcMain.handle('get-printers', async () => {
  if (!mainWindow || mainWindow.isDestroyed()) return [];
  try {
    const wc = mainWindow.webContents;
    const rawList =
      typeof wc.getPrintersAsync === 'function'
        ? await wc.getPrintersAsync()
        : typeof wc.getPrinters === 'function'
        ? wc.getPrinters()
        : [];

    if (!Array.isArray(rawList)) return [];
    return rawList.map((p) => ({
      name: String(p.name || ''),
      displayName: p.displayName ? String(p.displayName) : String(p.name || ''),
      isDefault: Boolean(p.isDefault),
    }));
  } catch {
    return [];
  }
});

// Execute A4 Portrait print (silent or OS dialog)
ipcMain.handle('print-invoice', async (_event, options = {}) => {
  if (!mainWindow || mainWindow.isDestroyed()) {
    return { success: false, failureReason: 'نافذة التطبيق غير جاهزة للطباعة' };
  }

  return new Promise((resolve) => {
    try {
      const printOptions = {
        silent: Boolean(options.silent),
        printBackground: options.printBackground !== false,
        landscape: false,
        pageSize: 'A4',
      };

      if (typeof options.deviceName === 'string' && options.deviceName.trim() !== '') {
        printOptions.deviceName = options.deviceName.trim();
      }

      mainWindow.webContents.print(printOptions, (success, failureReason) => {
        resolve({
          success: Boolean(success),
          failureReason: failureReason ? String(failureReason) : undefined,
        });
      });
    } catch (err) {
      resolve({
        success: false,
        failureReason: err instanceof Error ? err.message : 'تعذر بدء الطباعة',
      });
    }
  });
});

app.whenReady().then(() => {
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
