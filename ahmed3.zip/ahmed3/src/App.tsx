import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  User,
  Phone,
  FileText,
  Plus,
  Trash2,
  Printer,
  Save,
  Eye,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Info,
  Banknote,
  CreditCard,
  ArrowLeftRight,
  Calendar,
  Clock,
  Menu,
  ArrowRight,
} from 'lucide-react';
import {
  AccessMode,
  AppSettings,
  Invoice,
  InvoiceItem,
  PaymentMethod,
  ToastMessage,
} from './types';
import {
  DEFAULT_SETTINGS,
  FIXED_BANNER_IMAGE,
  FIXED_SHOP_ADDRESS,
  FIXED_SHOP_PHONE,
  collectProductSuggestions,
  createEmptyItem,
  formatDateYYYYMMDD,
  formatIqd,
  formatSerialNumber,
  formatTimeArabic12h,
  generateId,
  getNextSerialNumber,
  loadSettings,
  parseNumericInput,
  saveLastSerial,
  saveSettings,
} from './utils/storage';
import { numberToArabicIqdWords } from './utils/arabicTafqeet';
import {
  dbBulkPutInvoices,
  dbDeleteInvoice,
  dbFactoryResetAll,
  dbInitAndLoadInvoices,
  dbPutInvoice,
} from './utils/invoiceDb';
import { LoginScreen } from './components/LoginScreen';
import { ActiveTab, Sidebar } from './components/Sidebar';
import { InventoryView } from './components/InventoryView';
import { SettingsView } from './components/SettingsView';
import { ConfirmModal } from './components/ConfirmModal';
import { PrintPreviewModal } from './components/PrintPreviewModal';
import { InvoiceReceipt } from './components/InvoiceReceipt';

const MAX_DEMO_ITEMS = 2;

export default function App() {
  // Authentication / Access mode state (null = show login screen)
  const [accessMode, setAccessMode] = useState<AccessMode | null>(null);

  // Persistent state (full mode loads from IndexedDB/localStorage; demo mode stays strictly in memory)
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isLoadingInvoices, setIsLoadingInvoices] = useState<boolean>(false);

  // Live clock updated every second
  const [now, setNow] = useState<Date>(() => new Date());

  // Navigation state (pure React state — no URL routing for Electron EXE compatibility)
  const [activeTab, setActiveTab] = useState<ActiveTab>('cashier');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  // Active invoice form state
  const [activeInvoiceId, setActiveInvoiceId] = useState<string | null>(null);
  const [activeSerialNumber, setActiveSerialNumber] = useState<string | null>(null);
  const [activeNumericSerial, setActiveNumericSerial] = useState<number | null>(null);
  const [loadedDateDisplay, setLoadedDateDisplay] = useState<string | null>(null);
  const [loadedTimeDisplay, setLoadedTimeDisplay] = useState<string | null>(null);
  const [isSavedClean, setIsSavedClean] = useState<boolean>(false);

  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerNotes, setCustomerNotes] = useState<string>('');
  const [items, setItems] = useState<InvoiceItem[]>(() => [createEmptyItem()]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');

  // Overlays & printing state
  const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [isFactoryResetConfirmOpen, setIsFactoryResetConfirmOpen] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [printRequestSeq, setPrintRequestSeq] = useState(0);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const isPrintingRef = useRef<boolean>(false);
  const lastHandledPrintSeqRef = useRef<number>(0);

  // Hydrate persistent data ONLY in full-access mode; keep demo mode strictly isolated in memory
  useEffect(() => {
    if (accessMode === null) {
      setInvoices([]);
      setSettings(DEFAULT_SETTINGS);
      setIsLoadingInvoices(false);
      return;
    }

    if (accessMode === 'demo') {
      setInvoices([]);
      setSettings(DEFAULT_SETTINGS);
      setIsLoadingInvoices(false);
      return;
    }

    let cancelled = false;
    setSettings(loadSettings());
    setIsLoadingInvoices(true);

    const hydrate = async () => {
      try {
        const loadedInvoices = await dbInitAndLoadInvoices();
        if (cancelled) return;
        setInvoices(loadedInvoices);
      } finally {
        if (!cancelled) {
          setIsLoadingInvoices(false);
        }
      }
    };
    void hydrate();
    return () => {
      cancelled = true;
    };
  }, [accessMode]);

  // Update live clock every 1 second
  useEffect(() => {
    const timer = window.setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Toast helper
  const notify = useCallback((type: ToastMessage['type'], text: string) => {
    const id = generateId();
    setToasts((prev) => [...prev.slice(-2), { id, type, text }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3400);
  }, []);

  // Derived totals (Iraqi Dinar only)
  const totalIqd = useMemo(() => {
    return items.reduce((sum, item) => {
      const qty = Number.isFinite(item.quantity) ? item.quantity : 0;
      const price = Number.isFinite(item.unitPrice) ? item.unitPrice : 0;
      return sum + Math.round(qty * price);
    }, 0);
  }, [items]);

  const totalPieces = useMemo(() => {
    return items.reduce((sum, item) => {
      const hasContent =
        item.name.trim() !== '' || item.unitPrice > 0 || item.notes.trim() !== '';
      if (!hasContent) return sum;
      return sum + (Number.isFinite(item.quantity) ? item.quantity : 0);
    }, 0);
  }, [items]);

  const activeItemCount = useMemo(() => {
    return items.filter(
      (item) => item.name.trim() !== '' || item.unitPrice > 0 || item.notes.trim() !== ''
    ).length;
  }, [items]);

  const tafqeetText = useMemo(() => numberToArabicIqdWords(totalIqd), [totalIqd]);

  const productSuggestions = useMemo(() => collectProductSuggestions(invoices), [invoices]);

  const displayDate = loadedDateDisplay ?? formatDateYYYYMMDD(now);
  const displayTime = loadedTimeDisplay ?? formatTimeArabic12h(now);
  const nextSerialNum = useMemo(() => {
    if (accessMode === 'demo') {
      const maxDemo = invoices.reduce((max, inv) => Math.max(max, inv.numericSerial || 0), 0);
      return maxDemo + 1;
    }
    return getNextSerialNumber(invoices);
  }, [accessMode, invoices]);
  const displaySerial = activeSerialNumber ?? formatSerialNumber(nextSerialNum);

  const markDirty = () => {
    if (isSavedClean) setIsSavedClean(false);
  };

  // Item handlers
  const handleAddItem = () => {
    if (accessMode === 'demo' && items.length >= MAX_DEMO_ITEMS) {
      notify('error', 'النسخة التجريبية تسمح بإضافة صنفين فقط كحد أقصى');
      return;
    }
    setItems((prev) => [...prev, createEmptyItem()]);
    markDirty();
  };

  const handleRemoveItem = (id: string) => {
    setItems((prev) => {
      const next = prev.filter((item) => item.id !== id);
      return next.length > 0 ? next : [createEmptyItem()];
    });
    markDirty();
  };

  const handleUpdateItem = <K extends keyof InvoiceItem>(
    id: string,
    field: K,
    value: InvoiceItem[K]
  ) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
    markDirty();
  };

  // Save invoice: persistent IndexedDB in full mode, isolated ephemeral memory in demo mode
  const persistCurrentInvoice = useCallback(
    async (showToast: boolean): Promise<Invoice | null> => {
      if (!accessMode) return null;

      const nonEmptyItems = items.filter(
        (it) => it.name.trim() !== '' || it.unitPrice > 0 || it.notes.trim() !== ''
      );
      if (nonEmptyItems.length === 0) {
        notify('error', 'يرجى إدخال صنف واحد على الأقل قبل حفظ الفاتورة');
        return null;
      }

      if (accessMode === 'demo' && nonEmptyItems.length > MAX_DEMO_ITEMS) {
        notify('error', 'النسخة التجريبية تسمح بإضافة صنفين فقط كحد أقصى');
        return null;
      }

      const timestamp = new Date();
      const dateStr = loadedDateDisplay ?? formatDateYYYYMMDD(timestamp);
      const timeStr = loadedTimeDisplay ?? formatTimeArabic12h(timestamp);

      let targetNumericSerial = activeNumericSerial;
      let targetSerialStr = activeSerialNumber;
      let targetId = activeInvoiceId;

      if (!targetId || !targetNumericSerial || !targetSerialStr) {
        targetNumericSerial =
          accessMode === 'demo'
            ? invoices.reduce((max, inv) => Math.max(max, inv.numericSerial || 0), 0) + 1
            : getNextSerialNumber(invoices);
        targetSerialStr = formatSerialNumber(targetNumericSerial);
        targetId = generateId();
      }

      const computedTotalIqd = nonEmptyItems.reduce(
        (sum, it) => sum + Math.round((Number(it.quantity) || 0) * (Number(it.unitPrice) || 0)),
        0
      );

      const invoiceRecord: Invoice = {
        id: targetId,
        serialNumber: targetSerialStr,
        numericSerial: targetNumericSerial,
        createdAt: timestamp.toISOString(),
        dateDisplay: dateStr,
        timeDisplay: timeStr,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerNotes: customerNotes.trim(),
        items: nonEmptyItems,
        paymentMethod,
        totalIqd: computedTotalIqd,
      };

      const existingIdx = invoices.findIndex((inv) => inv.id === targetId);
      const updatedList =
        existingIdx >= 0
          ? invoices.map((inv) => (inv.id === targetId ? invoiceRecord : inv))
          : [invoiceRecord, ...invoices];

      // Only persist to IndexedDB/localStorage in full mode; demo data is never stored with full account
      if (accessMode === 'full') {
        const savedOk = await dbPutInvoice(invoiceRecord, updatedList);
        if (!savedOk) {
          notify('error', 'تعذر حفظ الفاتورة في قاعدة البيانات المحلية');
          return null;
        }

        saveLastSerial(
          Math.max(
            targetNumericSerial,
            updatedList.reduce((m, i) => Math.max(m, i.numericSerial || 0), 0)
          )
        );
      }

      setInvoices(updatedList);
      setActiveInvoiceId(targetId);
      setActiveNumericSerial(targetNumericSerial);
      setActiveSerialNumber(targetSerialStr);
      setLoadedDateDisplay(dateStr);
      setLoadedTimeDisplay(timeStr);
      setIsSavedClean(true);

      if (showToast) {
        notify(
          'success',
          existingIdx >= 0
            ? `تم تحديث الفاتورة رقم ${targetSerialStr} بنجاح`
            : `تم حفظ الفاتورة رقم ${targetSerialStr} بنجاح`
        );
      }

      return invoiceRecord;
    },
    [
      accessMode,
      items,
      loadedDateDisplay,
      loadedTimeDisplay,
      activeNumericSerial,
      activeSerialNumber,
      activeInvoiceId,
      invoices,
      customerName,
      customerPhone,
      customerNotes,
      paymentMethod,
      notify,
    ]
  );

  // Wait for Cairo font + any uploaded banner image in #printable-receipt-root before spooling
  const waitForPrintReadiness = useCallback(async () => {
    if (typeof document !== 'undefined' && document.fonts?.ready) {
      await Promise.race([
        document.fonts.ready.catch(() => undefined),
        new Promise((resolve) => window.setTimeout(resolve, 500)),
      ]);
    }

    const printRoot = document.getElementById('printable-receipt-root');
    if (printRoot) {
      const imgs = Array.from(printRoot.querySelectorAll('img'));
      if (imgs.length > 0) {
        await Promise.race([
          Promise.all(
            imgs.map((img) => {
              if (img.complete && img.naturalWidth > 0) return Promise.resolve();
              return typeof img.decode === 'function'
                ? img.decode().catch(() => undefined)
                : new Promise<void>((resolve) => {
                    img.onload = () => resolve();
                    img.onerror = () => resolve();
                  });
            })
          ),
          new Promise((resolve) => window.setTimeout(resolve, 800)),
        ]);
      }
    }

    await new Promise<void>((resolve) => {
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => resolve());
      });
    });
  }, []);

  // Execute physical print (Electron USB/cable direct API or browser window.print)
  const triggerPrintEngine = useCallback(async () => {
    if (isPrintingRef.current) return;
    isPrintingRef.current = true;
    setIsPrinting(true);

    const originalTitle = document.title;
    const safeSerial = displaySerial.replace(/[^0-9A-Za-z#-]/g, '');
    document.title = `فاتورة ${safeSerial} - أحمد القيسي للإطارات والبطاريات`;

    const releaseLock = () => {
      document.title = originalTitle;
      isPrintingRef.current = false;
      setIsPrinting(false);
    };

    try {
      await waitForPrintReadiness();

      const electronPrint = window.electronAPI?.printInvoice;
      if (typeof electronPrint === 'function') {
        const result = await electronPrint({
          deviceName: settings.selectedPrinter || undefined,
          silent: settings.silentPrint,
          printBackground: true,
          landscape: false,
          pageSize: 'A4',
        });
        if (!result?.success) {
          notify(
            'error',
            result?.failureReason
              ? `فشلت الطباعة: ${result.failureReason}`
              : 'لم تكتمل عملية الطباعة — تأكد من توصيل كيبل الطابعة وتشغيلها'
          );
        } else if (settings.silentPrint) {
          notify('success', 'تم إرسال الفاتورة إلى الطابعة مباشرة بنجاح');
        }
        releaseLock();
      } else {
        let released = false;
        const finishBrowserPrint = () => {
          if (released) return;
          released = true;
          window.removeEventListener('afterprint', finishBrowserPrint);
          releaseLock();
        };
        window.addEventListener('afterprint', finishBrowserPrint);

        const safetyTimer = window.setTimeout(finishBrowserPrint, 2500);
        try {
          window.print();
        } finally {
          window.setTimeout(() => {
            window.clearTimeout(safetyTimer);
            finishBrowserPrint();
          }, 400);
        }
      }
    } catch {
      notify('error', 'حدث خطأ أثناء الاتصال بالطابعة — تحقق من توصيل الكيبل');
      releaseLock();
    }
  }, [
    displaySerial,
    waitForPrintReadiness,
    settings.selectedPrinter,
    settings.silentPrint,
    notify,
  ]);

  // Guaranteed one-shot post-render print trigger
  useEffect(() => {
    if (printRequestSeq === 0 || printRequestSeq === lastHandledPrintSeqRef.current) {
      return;
    }
    lastHandledPrintSeqRef.current = printRequestSeq;
    void triggerPrintEngine();
  }, [printRequestSeq, triggerPrintEngine]);

  const handleSaveInvoice = () => {
    void persistCurrentInvoice(true);
  };

  const executeActualPrint = async () => {
    if (isPrintingRef.current) return;
    setIsPrintPreviewOpen(false);
    if (!isSavedClean || !activeInvoiceId) {
      const saved = await persistCurrentInvoice(false);
      if (!saved) return;
      notify('info', `تم حفظ الفاتورة ${saved.serialNumber} وإرسالها للطباعة`);
    }
    setPrintRequestSeq((seq) => seq + 1);
  };

  const handlePrintInvoice = () => {
    if (isPrintingRef.current) return;
    if (activeItemCount === 0) {
      notify('error', 'يرجى إدخال صنف واحد على الأقل قبل معاينة أو طباعة الفاتورة');
      return;
    }
    if (accessMode === 'demo' && activeItemCount > MAX_DEMO_ITEMS) {
      notify('error', 'النسخة التجريبية تسمح بإضافة صنفين فقط كحد أقصى');
      return;
    }

    const isSilentElectron =
      typeof window !== 'undefined' &&
      typeof window.electronAPI?.printInvoice === 'function' &&
      settings.silentPrint;

    if (isSilentElectron) {
      void executeActualPrint();
    } else {
      setIsPrintPreviewOpen(true);
    }
  };

  const handleSaveSettings = async (nextSettings: AppSettings) => {
    const lockedSettings: AppSettings = {
      ...nextSettings,
      bannerImage: FIXED_BANNER_IMAGE,
      shopAddress: FIXED_SHOP_ADDRESS,
      shopPhone: FIXED_SHOP_PHONE,
      paperSize: 'A4_PORTRAIT',
    };

    if (accessMode === 'full') {
      const ok = saveSettings(lockedSettings);
      if (!ok) {
        notify('error', 'فشل حفظ الإعدادات');
        return;
      }
    }
    setSettings(lockedSettings);
    notify('success', 'تم حفظ إعدادات النظام بنجاح');
  };

  const handleTestPrint = async (draftSettings: AppSettings) => {
    await handleSaveSettings(draftSettings);
    setPrintRequestSeq((seq) => seq + 1);
  };

  // Reset form for a fresh blank invoice
  const resetToFreshInvoice = (showToast = true) => {
    setActiveInvoiceId(null);
    setActiveSerialNumber(null);
    setActiveNumericSerial(null);
    setLoadedDateDisplay(null);
    setLoadedTimeDisplay(null);
    setIsSavedClean(false);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerNotes('');
    setItems([createEmptyItem()]);
    setPaymentMethod('cash');
    setIsCancelConfirmOpen(false);
    setActiveTab('cashier');
    if (showToast) {
      notify('info', 'تم تفريغ الحقول لبدء فاتورة جديدة');
    }
  };

  // Sidebar quick "New Invoice" handler (never loses unsaved work)
  const handleSidebarNewInvoice = () => {
    if (activeInvoiceId && isSavedClean) {
      resetToFreshInvoice(true);
      return;
    }
    if (activeItemCount > 0 && !isSavedClean) {
      setActiveTab('cashier');
      setIsCancelConfirmOpen(true);
      return;
    }
    setActiveTab('cashier');
  };

  // Load saved invoice from Inventory view
  const handleLoadInvoice = (invoice: Invoice, autoPrint = false) => {
    setActiveInvoiceId(invoice.id);
    setActiveSerialNumber(invoice.serialNumber);
    setActiveNumericSerial(invoice.numericSerial);
    setLoadedDateDisplay(invoice.dateDisplay);
    setLoadedTimeDisplay(invoice.timeDisplay);
    setCustomerName(invoice.customerName);
    setCustomerPhone(invoice.customerPhone);
    setCustomerNotes(invoice.customerNotes);
    setItems(invoice.items.length > 0 ? invoice.items.map((it) => ({ ...it })) : [createEmptyItem()]);
    setPaymentMethod(invoice.paymentMethod);
    setIsSavedClean(true);
    setActiveTab('cashier');

    if (autoPrint) {
      setPrintRequestSeq((seq) => seq + 1);
    } else {
      notify('info', `تم فتح الفاتورة رقم ${invoice.serialNumber}`);
    }
  };

  const handleDeleteInvoice = async (id: string) => {
    const target = invoices.find((inv) => inv.id === id);
    const updated = invoices.filter((inv) => inv.id !== id);
    if (accessMode === 'full') {
      const deletedOk = await dbDeleteInvoice(id, updated);
      if (!deletedOk) {
        notify('error', 'تعذر حذف الفاتورة من قاعدة البيانات المحلية');
        return;
      }
    }
    setInvoices(updated);
    if (activeInvoiceId === id) {
      setActiveInvoiceId(null);
      setActiveSerialNumber(null);
      setActiveNumericSerial(null);
      setIsSavedClean(false);
    }
    notify('info', `تم حذف الفاتورة ${target?.serialNumber ?? ''}`);
  };

  const handleImportInvoices = async (imported: Invoice[]) => {
    const normalizedImported =
      accessMode === 'demo'
        ? imported.map((inv) => ({
            ...inv,
            items: inv.items.slice(0, MAX_DEMO_ITEMS),
          }))
        : imported;

    const byId = new Map<string, Invoice>();
    for (const inv of invoices) byId.set(inv.id, inv);
    for (const inv of normalizedImported) byId.set(inv.id, inv);
    const merged = Array.from(byId.values()).sort(
      (a, b) => (b.numericSerial || 0) - (a.numericSerial || 0)
    );

    if (accessMode === 'full') {
      const savedOk = await dbBulkPutInvoices(normalizedImported, merged);
      if (!savedOk) {
        notify('error', 'تعذر حفظ الفواتير المستوردة في قاعدة البيانات');
        return;
      }
      const maxSerial = merged.reduce((m, i) => Math.max(m, i.numericSerial || 0), 0);
      saveLastSerial(maxSerial);
    }

    setInvoices(merged);
    notify(
      'success',
      `تم استيراد ${normalizedImported.length} فاتورة بنجاح (الإجمالي: ${merged.length})`
    );
  };

  const handleLogin = (mode: AccessMode) => {
    resetToFreshInvoice(false);
    setIsSidebarOpen(false);
    setIsPrintPreviewOpen(false);
    setIsCancelConfirmOpen(false);
    setIsFactoryResetConfirmOpen(false);
    setAccessMode(mode);
    notify(
      mode === 'full' ? 'success' : 'info',
      mode === 'full'
        ? 'تم تسجيل الدخول بصلاحيات كاملة'
        : 'تم الدخول إلى النسخة التجريبية (صنفان كحد أقصى)'
    );
  };

  const handleLogout = () => {
    resetToFreshInvoice(false);
    setInvoices([]);
    setSettings(DEFAULT_SETTINGS);
    setIsSidebarOpen(false);
    setIsPrintPreviewOpen(false);
    setIsCancelConfirmOpen(false);
    setIsFactoryResetConfirmOpen(false);
    setAccessMode(null);
  };

  const handleConfirmFactoryReset = async () => {
    if (accessMode !== 'full') return;
    const ok = await dbFactoryResetAll();
    if (!ok) {
      notify('error', 'تعذر إتمام إعادة ضبط المصنع');
      setIsFactoryResetConfirmOpen(false);
      return;
    }
    setInvoices([]);
    setSettings(DEFAULT_SETTINGS);
    resetToFreshInvoice(false);
    setIsFactoryResetConfirmOpen(false);
    notify('success', 'تمت إعادة ضبط المصنع وحذف جميع البيانات بنجاح');
  };

  if (accessMode === null) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  const pageCssRule = '@page { size: A4 portrait; margin: 8mm; }';

  const currentViewTitle =
    activeTab === 'cashier'
      ? 'نقطة البيع'
      : activeTab === 'inventory'
      ? 'سجل الفواتير والجرد'
      : 'إعدادات النظام والطباعة';

  return (
    <div className="pos-page-wrapper min-h-screen bg-[#F5F7F8] text-[#1E293B]">
      {/* Fixed A4 Portrait @page rule */}
      <style>{pageCssRule}</style>

      {/* ================================================================
          INTERACTIVE POS DESKTOP SHELL (Hidden on Print)
         ================================================================ */}
      <div className="print:hidden flex min-h-screen w-full">
        {/* Collapsible Right Sidebar (RTL) + Responsive Mobile Drawer */}
        <Sidebar
          accessMode={accessMode}
          onLogout={handleLogout}
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          savedCount={invoices.length}
          hasActiveSavedInvoice={Boolean(activeInvoiceId)}
          onNewInvoice={handleSidebarNewInvoice}
          onOpenPreview={() => setIsPrintPreviewOpen(true)}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />

        {/* Main Fluid Content Area */}
        <div className="flex-1 min-w-0 flex flex-col">
          {/* Calm Top Context Header */}
          <header className="sticky top-0 z-30 bg-white border-b border-[#E2E8EE] px-4 sm:px-6 h-14 flex items-center justify-between gap-4 select-none">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setIsSidebarOpen((prev) => !prev)}
                className="p-2 -mr-2 rounded-lg text-[#475569] hover:text-[#1E293B] hover:bg-[#F1F5F7] transition-colors cursor-pointer"
                aria-expanded={isSidebarOpen}
                aria-label={isSidebarOpen ? 'إغلاق القائمة الجانبية' : 'فتح القائمة الجانبية'}
                title={isSidebarOpen ? 'إغلاق القائمة الجانبية' : 'فتح القائمة الجانبية'}
              >
                <Menu className="w-5 h-5" />
              </button>

              <h1 className="text-base sm:text-lg font-extrabold text-[#1E293B] truncate">
                {currentViewTitle}
              </h1>

              {activeTab === 'cashier' && (
                <div className="hidden md:flex items-center gap-2.5 text-xs font-semibold text-[#64748B] tabular-nums pr-2 border-r border-[#E2E8EE]">
                  <span>
                    {activeSerialNumber ? 'فاتورة محفوظة' : 'فاتورة رقم'}{' '}
                    <strong dir="ltr" className="text-[#0F766E] font-extrabold">
                      {displaySerial}
                    </strong>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#94A3B8]" />
                    <span dir="ltr" className="text-[#334155]">
                      {displayDate}
                    </span>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#94A3B8]" />
                    <span className="text-[#334155]">{displayTime}</span>
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {activeTab === 'cashier' ? (
                <button
                  type="button"
                  onClick={() => setIsPrintPreviewOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFB] hover:border-[#0F766E] text-[#1E293B] text-xs sm:text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Eye className="w-4 h-4 text-[#0F766E]" />
                  <span>معاينة الوصل</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setActiveTab('cashier')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFB] hover:border-[#0F766E] text-[#1E293B] text-xs sm:text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
                >
                  <ArrowRight className="w-4 h-4 text-[#0F766E]" />
                  <span>العودة لنقطة البيع</span>
                </button>
              )}
            </div>
          </header>

          {/* Compact Mobile Date/Time Strip (Cashier only below md) */}
          {activeTab === 'cashier' && (
            <div className="md:hidden bg-white border-b border-[#E2E8EE] px-4 py-2 flex items-center justify-between text-xs font-bold text-[#475569] tabular-nums">
              <span>
                فاتورة{' '}
                <strong dir="ltr" className="text-[#0F766E]">
                  {displaySerial}
                </strong>
              </span>
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-[#94A3B8]" />
                  <span dir="ltr">{displayDate}</span>
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-[#94A3B8]" />
                  <span>{displayTime}</span>
                </span>
              </div>
            </div>
          )}

          {/* Active Workspace Canvas */}
          <main className="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 py-5">
            {activeTab === 'cashier' && (
              <div className="space-y-4">
                {/* Customer Details Bar */}
                <section
                  aria-label="بيانات الزبون"
                  className="bg-white rounded-xl border border-[#E2E8EE] p-4"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <label
                        htmlFor="customer-name"
                        className="flex items-center gap-1.5 text-xs font-bold text-[#475569] mb-1.5"
                      >
                        <User className="w-3.5 h-3.5 text-[#64748B]" />
                        <span>اسم الزبون</span>
                      </label>
                      <input
                        id="customer-name"
                        type="text"
                        value={customerName}
                        onChange={(e) => {
                          setCustomerName(e.target.value);
                          markDirty();
                        }}
                        className="w-full h-10 px-3 rounded-lg bg-[#F8FAFB] hover:bg-white focus:bg-white border border-[#CBD5E1] focus:border-[#0F766E] text-[#1E293B] font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-[rgba(15,118,110,0.18)]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="customer-phone"
                        className="flex items-center gap-1.5 text-xs font-bold text-[#475569] mb-1.5"
                      >
                        <Phone className="w-3.5 h-3.5 text-[#64748B]" />
                        <span>رقم الهاتف</span>
                      </label>
                      <input
                        id="customer-phone"
                        type="text"
                        dir="ltr"
                        value={customerPhone}
                        onChange={(e) => {
                          setCustomerPhone(e.target.value);
                          markDirty();
                        }}
                        className="w-full h-10 px-3 rounded-lg bg-[#F8FAFB] hover:bg-white focus:bg-white border border-[#CBD5E1] focus:border-[#0F766E] text-[#1E293B] font-semibold text-sm text-right tabular-nums transition-colors focus:outline-none focus:ring-2 focus:ring-[rgba(15,118,110,0.18)]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="customer-notes"
                        className="flex items-center gap-1.5 text-xs font-bold text-[#475569] mb-1.5"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#64748B]" />
                        <span>ملاحظات الفاتورة</span>
                      </label>
                      <input
                        id="customer-notes"
                        type="text"
                        value={customerNotes}
                        onChange={(e) => {
                          setCustomerNotes(e.target.value);
                          markDirty();
                        }}
                        className="w-full h-10 px-3 rounded-lg bg-[#F8FAFB] hover:bg-white focus:bg-white border border-[#CBD5E1] focus:border-[#0F766E] text-[#1E293B] font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-[rgba(15,118,110,0.18)]"
                      />
                    </div>
                  </div>
                </section>

                {/* Items Ledger Table (Full Width) */}
                <section
                  aria-label="جدول الأصناف"
                  className="bg-white rounded-xl border border-[#E2E8EE] overflow-hidden"
                >
                  {/* Section Header */}
                  <div className="px-4 py-3 border-b border-[#E2E8EE] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-sm font-extrabold text-[#1E293B]">تفاصيل الأصناف</h2>
                      <span className="text-xs font-semibold text-[#64748B] tabular-nums">
                        · {activeItemCount} صنف · {totalPieces} قطعة
                      </span>
                      {accessMode === 'demo' && (
                        <span className="text-xs font-bold text-[#B45309] tabular-nums">
                          · النسخة التجريبية ({items.length} / {MAX_DEMO_ITEMS} كحد أقصى)
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={handleAddItem}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-white text-xs font-bold transition-colors whitespace-nowrap ${
                        accessMode === 'demo' && items.length >= MAX_DEMO_ITEMS
                          ? 'bg-[#94A3B8] cursor-not-allowed'
                          : 'bg-[#0F766E] hover:bg-[#115E59] cursor-pointer'
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>إضافة صنف</span>
                    </button>
                  </div>

                  {/* Datalist for product autocomplete */}
                  <datalist id="product-suggestions">
                    {productSuggestions.map((prod) => (
                      <option key={prod} value={prod} />
                    ))}
                  </datalist>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-[#F8FAFB] border-b border-[#E2E8EE] text-xs font-bold text-[#475569]">
                          <th className="py-2.5 px-3 text-center w-[44px]">ت</th>
                          <th className="py-2.5 px-3 text-right min-w-[240px]">الصنف / البيان</th>
                          <th className="py-2.5 px-2 text-center w-[80px]">الكمية</th>
                          <th className="py-2.5 px-2 text-center w-[140px] whitespace-nowrap">
                            سعر الوحدة (د.ع)
                          </th>
                          <th className="py-2.5 px-2 text-center min-w-[160px] w-[170px]">الضمان</th>
                          <th className="py-2.5 px-3 text-center w-[140px] whitespace-nowrap">
                            المجموع (د.ع)
                          </th>
                          <th className="py-2.5 px-2 text-right min-w-[150px]">ملاحظات</th>
                          <th className="py-2.5 px-2 w-[44px]">
                            <span className="sr-only">حذف</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#EEF2F5] text-sm">
                        {items.map((item, idx) => {
                          const rowTotal = Math.round(
                            (Number.isFinite(item.quantity) ? item.quantity : 0) *
                              (Number.isFinite(item.unitPrice) ? item.unitPrice : 0)
                          );
                          const isLastRow = idx === items.length - 1;

                          return (
                            <tr
                              key={item.id}
                              className="group hover:bg-[#F8FAFB] transition-colors"
                            >
                              <td className="py-2 px-3 text-center text-xs font-bold text-[#64748B] tabular-nums">
                                {idx + 1}
                              </td>

                              <td className="py-2 px-2">
                                <input
                                  type="text"
                                  list="product-suggestions"
                                  value={item.name}
                                  onChange={(e) =>
                                    handleUpdateItem(item.id, 'name', e.target.value)
                                  }
                                  aria-label={`الصنف ${idx + 1}`}
                                  className="w-full h-9 px-2.5 rounded-md bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-[#CBD5E1] focus:border-[#0F766E] text-[#1E293B] font-bold text-sm text-right focus:outline-none transition-colors"
                                />
                              </td>

                              <td className="py-2 px-1.5">
                                <input
                                  type="number"
                                  min={1}
                                  step={1}
                                  value={item.quantity === 0 ? '' : item.quantity}
                                  onChange={(e) => {
                                    const val = Number.parseInt(e.target.value, 10);
                                    handleUpdateItem(
                                      item.id,
                                      'quantity',
                                      Number.isFinite(val) && val >= 0 ? val : 0
                                    );
                                  }}
                                  aria-label={`الكمية ${idx + 1}`}
                                  className="w-full h-9 px-2 rounded-md bg-[#F8FAFB] focus:bg-white border border-[#E2E8EE] focus:border-[#0F766E] text-[#1E293B] font-bold text-sm text-center tabular-nums focus:outline-none transition-colors"
                                />
                              </td>

                              <td className="py-2 px-1.5">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  value={item.unitPrice === 0 ? '' : formatIqd(item.unitPrice)}
                                  onChange={(e) => {
                                    handleUpdateItem(
                                      item.id,
                                      'unitPrice',
                                      parseNumericInput(e.target.value)
                                    );
                                  }}
                                  aria-label={`سعر الوحدة ${idx + 1}`}
                                  className="w-full h-9 px-2.5 rounded-md bg-[#F8FAFB] focus:bg-white border border-[#E2E8EE] focus:border-[#0F766E] text-[#1E293B] font-bold text-sm text-center tabular-nums focus:outline-none transition-colors"
                                />
                              </td>

                              <td className="py-2 px-1.5">
                                <input
                                  type="text"
                                  value={item.warranty}
                                  onChange={(e) =>
                                    handleUpdateItem(item.id, 'warranty', e.target.value)
                                  }
                                  aria-label={`الضمان ${idx + 1}`}
                                  className="w-full h-9 px-2.5 rounded-md bg-[#F8FAFB] hover:bg-white focus:bg-white border border-[#E2E8EE] hover:border-[#CBD5E1] focus:border-[#0F766E] text-[#1E293B] font-semibold text-sm text-center focus:outline-none transition-colors"
                                />
                              </td>

                              <td className="py-2 px-3 text-center font-extrabold text-[#0F766E] text-sm tabular-nums whitespace-nowrap">
                                {formatIqd(rowTotal)}
                              </td>

                              <td className="py-2 px-1.5">
                                <input
                                  type="text"
                                  value={item.notes}
                                  onChange={(e) =>
                                    handleUpdateItem(item.id, 'notes', e.target.value)
                                  }
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter' && isLastRow) {
                                      e.preventDefault();
                                      handleAddItem();
                                    }
                                  }}
                                  aria-label={`ملاحظات ${idx + 1}`}
                                  className="w-full h-9 px-2 rounded-md bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-[#CBD5E1] focus:border-[#0F766E] text-[#475569] font-medium text-xs sm:text-sm text-right focus:outline-none transition-colors"
                                />
                              </td>

                              <td className="py-2 px-2 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleRemoveItem(item.id)}
                                  className="p-1.5 rounded-md text-[#94A3B8] hover:text-[#BE123C] hover:bg-[#FFF1F2] transition-colors cursor-pointer"
                                  title="حذف الصف"
                                  aria-label={`حذف الصف ${idx + 1}`}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Bottom Add-Row Affordance */}
                  <div className="px-4 py-2 bg-[#F8FAFB] border-t border-[#E2E8EE] flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={handleAddItem}
                      className={`inline-flex items-center gap-1.5 text-xs font-bold transition-colors py-1 ${
                        accessMode === 'demo' && items.length >= MAX_DEMO_ITEMS
                          ? 'text-[#94A3B8] cursor-not-allowed'
                          : 'text-[#0F766E] hover:text-[#115E59] cursor-pointer'
                      }`}
                    >
                      <Plus className="w-4 h-4" />
                      <span>إضافة سطر جديد</span>
                    </button>

                    {accessMode === 'demo' && items.length >= MAX_DEMO_ITEMS && (
                      <span className="text-[11px] font-bold text-[#B45309]">
                        تم الوصول للحد الأقصى في الوضع التجريبي (صنفان)
                      </span>
                    )}
                  </div>
                </section>

                {/* Compact Horizontal Checkout & Action Bar */}
                <section
                  aria-label="ملخص الدفع والإجراءات"
                  className="bg-white rounded-xl border border-[#E2E8EE] px-4 sm:px-5 py-3.5"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    {/* Right Side: Payment Method + Tafqeet */}
                    <div className="flex flex-col gap-2.5 min-w-0 lg:max-w-[52%]">
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="text-xs font-bold text-[#475569] whitespace-nowrap">
                          طريقة الدفع
                        </span>
                        <div
                          role="radiogroup"
                          aria-label="طريقة الدفع"
                          className="inline-grid grid-cols-3 gap-1 p-1 rounded-lg bg-[#F1F5F7] border border-[#E2E8EE]"
                        >
                          {(
                            [
                              { value: 'cash' as PaymentMethod, label: 'نقداً', icon: Banknote },
                              { value: 'card' as PaymentMethod, label: 'بطاقة', icon: CreditCard },
                              {
                                value: 'transfer' as PaymentMethod,
                                label: 'تحويل',
                                icon: ArrowLeftRight,
                              },
                            ] as const
                          ).map((opt) => {
                            const Icon = opt.icon;
                            const active = paymentMethod === opt.value;
                            return (
                              <button
                                key={opt.value}
                                type="button"
                                role="radio"
                                aria-checked={active}
                                onClick={() => {
                                  setPaymentMethod(opt.value);
                                  markDirty();
                                }}
                                className={`flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                                  active
                                    ? 'bg-[#0F766E] text-white shadow-xs'
                                    : 'text-[#475569] hover:text-[#1E293B]'
                                }`}
                              >
                                <Icon className="w-3.5 h-3.5 shrink-0" />
                                <span>{opt.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <p className="text-xs font-semibold text-[#475569] leading-relaxed bg-[#F8FAFB] border border-[#E2E8EE] rounded-lg px-3 py-1.5">
                        {tafqeetText}
                      </p>
                    </div>

                    {/* Left Side: Total + Clear Action Hierarchy */}
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between lg:justify-end gap-4 lg:gap-5 pt-3 lg:pt-0 border-t lg:border-t-0 border-[#EEF2F5]">
                      {/* Total Amount */}
                      <div className="flex items-baseline sm:flex-col sm:items-end justify-between gap-1 shrink-0">
                        <span className="text-[11px] font-bold text-[#64748B]">
                          المجموع الكلي المستحق
                        </span>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-2xl sm:text-3xl font-black text-[#0F766E] tabular-nums tracking-tight">
                            {formatIqd(totalIqd)}
                          </span>
                          <span className="text-xs font-extrabold text-[#475569] whitespace-nowrap">
                            د.ع
                          </span>
                        </div>
                      </div>

                      {/* Primary / Secondary / Quiet Destructive Buttons */}
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          disabled={isPrinting}
                          onClick={handlePrintInvoice}
                          className="flex-1 sm:flex-initial py-2.5 px-5 rounded-lg bg-[#0F766E] hover:bg-[#115E59] disabled:opacity-60 disabled:cursor-not-allowed active:scale-[0.99] text-white font-extrabold text-sm flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap"
                        >
                          <Printer className="w-4 h-4 shrink-0" />
                          <span>{isPrinting ? 'جارٍ الإرسال...' : 'طباعة الفاتورة'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleSaveInvoice}
                          className="py-2.5 px-4 rounded-lg bg-[#15803D] hover:bg-[#166534] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <Save className="w-4 h-4 shrink-0" />
                          <span>حفظ الفاتورة</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setIsCancelConfirmOpen(true)}
                          title="إلغاء وتفريغ الفاتورة"
                          className="py-2.5 px-3 rounded-lg bg-white hover:bg-[#FFF1F2] text-[#BE123C] border border-[#E2E8EE] hover:border-[#FECDD3] font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                          <span>تفريغ</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            )}

            {activeTab === 'inventory' && (
              <InventoryView
                isLoading={isLoadingInvoices}
                invoices={invoices}
                onLoadInvoice={handleLoadInvoice}
                onDeleteInvoice={handleDeleteInvoice}
                onImportInvoices={handleImportInvoices}
                onGoToCashier={() => setActiveTab('cashier')}
                onNotify={notify}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                accessMode={accessMode}
                settings={settings}
                onSave={handleSaveSettings}
                onTestPrint={handleTestPrint}
                onRequestFactoryReset={() => setIsFactoryResetConfirmOpen(true)}
                onNotify={notify}
              />
            )}
          </main>
        </div>
      </div>

      {/* ================================================================
          DEDICATED PRINT-ENGINEERED COMMERCIAL RECEIPT (Matches Preview 1-to-1)
         ================================================================ */}
      <div id="printable-receipt-root" className="hidden print:block w-full">
        <InvoiceReceipt
          isDemoWatermark={accessMode === 'demo'}
          settings={settings}
          serialNumber={displaySerial}
          dateDisplay={displayDate}
          timeDisplay={displayTime}
          customerName={customerName}
          customerPhone={customerPhone}
          customerNotes={customerNotes}
          items={items}
          paymentMethod={paymentMethod}
          totalIqd={totalIqd}
        />
      </div>

      {/* FOCUSED OVERLAYS */}
      <PrintPreviewModal
        isOpen={isPrintPreviewOpen}
        isPrinting={isPrinting}
        isDemoWatermark={accessMode === 'demo'}
        onClose={() => setIsPrintPreviewOpen(false)}
        onConfirmPrint={() => void executeActualPrint()}
        settings={settings}
        serialNumber={displaySerial}
        dateDisplay={displayDate}
        timeDisplay={displayTime}
        customerName={customerName}
        customerPhone={customerPhone}
        customerNotes={customerNotes}
        items={items}
        paymentMethod={paymentMethod}
        totalIqd={totalIqd}
      />

      <ConfirmModal
        isOpen={isCancelConfirmOpen}
        title="تأكيد إلغاء الفاتورة"
        message="هل أنت متأكد من رغبتك في إلغاء الفاتورة الحالية وتفريغ جميع الحقول والأصناف لبدء فاتورة جديدة؟"
        confirmLabel="نعم، تفريغ الفاتورة"
        cancelLabel="تراجع"
        onConfirm={() => resetToFreshInvoice(true)}
        onCancel={() => setIsCancelConfirmOpen(false)}
      />

      <ConfirmModal
        isOpen={isFactoryResetConfirmOpen}
        title="تأكيد إعادة ضبط المصنع"
        message="تحذير: سيؤدي هذا الإجراء إلى حذف جميع الفواتير المحفوظة وسجل الجرد والأرقام التسلسلية وإعدادات النظام نهائياً ولا يمكن التراجع عنه. هل أنت متأكد؟"
        confirmLabel="نعم، حذف كل شيء"
        cancelLabel="تراجع"
        onConfirm={() => void handleConfirmFactoryReset()}
        onCancel={() => setIsFactoryResetConfirmOpen(false)}
      />

      {/* TOAST NOTIFICATIONS (Hidden on print) */}
      {toasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed bottom-5 left-5 z-50 flex flex-col gap-2 max-w-sm print:hidden"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border text-sm font-bold ${
                toast.type === 'success'
                  ? 'bg-[#15803D] text-white border-[#166534]'
                  : toast.type === 'error'
                  ? 'bg-[#BE123C] text-white border-[#9F1239]'
                  : 'bg-[#1C252C] text-white border-[#2D3B46]'
              }`}
            >
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : toast.type === 'error' ? (
                <AlertCircle className="w-5 h-5 shrink-0" />
              ) : (
                <Info className="w-5 h-5 text-[#5EEAD4] shrink-0" />
              )}
              <span>{toast.text}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
