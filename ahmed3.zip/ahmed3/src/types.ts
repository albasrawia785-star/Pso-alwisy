export type AccessMode = 'demo' | 'full';

export type PaymentMethod = 'cash' | 'card' | 'transfer';

export type PaperSize = 'A4_PORTRAIT';

export interface InvoiceItem {
  id: string;
  name: string;
  quantity: number;
  unitPrice: number;
  warranty: string;
  notes: string;
}

export interface Invoice {
  id: string;
  serialNumber: string; // e.g. "#0001"
  numericSerial: number;
  createdAt: string; // ISO string
  dateDisplay: string; // YYYY/MM/DD
  timeDisplay: string; // hh:mm ص/م
  customerName: string;
  customerPhone: string;
  customerNotes: string;
  items: InvoiceItem[];
  paymentMethod: PaymentMethod;
  totalIqd: number;
  /** Legacy fields retained as optional for seamless migration of older backups */
  iqdAmount?: number;
  totalUsd?: number;
}

export interface AppSettings {
  bannerImage: string | null; // Base64 Data URL or null for default artwork
  shopAddress: string;
  shopPhone: string;
  paperSize: PaperSize;
  selectedPrinter: string;
  silentPrint: boolean;
}

export interface ElectronPrinter {
  name: string;
  displayName?: string;
  isDefault?: boolean;
}

export interface ElectronAPI {
  getPrinters: () => Promise<Array<ElectronPrinter>>;
  printInvoice: (options: {
    deviceName?: string;
    silent?: boolean;
    printBackground?: boolean;
    landscape?: boolean;
    pageSize?: 'A4';
  }) => Promise<{ success: boolean; failureReason?: string }>;
}

declare global {
  interface Window {
    electronAPI?: ElectronAPI;
  }
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}
