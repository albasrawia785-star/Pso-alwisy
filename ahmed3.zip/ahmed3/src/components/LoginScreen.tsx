import React, { useState } from 'react';
import { Lock, Eye, EyeOff, LogIn, AlertCircle } from 'lucide-react';
import { AccessMode } from '../types';

interface LoginScreenProps {
  onLogin: (mode: AccessMode) => void;
}

const DEMO_ACCESS_CODE = '0000';
const FULL_ACCESS_CODE = '20261997';

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [code, setCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const normalized = code.trim();

    if (!normalized) {
      setError('يرجى إدخال رمز الدخول');
      return;
    }

    if (normalized === DEMO_ACCESS_CODE) {
      setError(null);
      onLogin('demo');
      return;
    }

    if (normalized === FULL_ACCESS_CODE) {
      setError(null);
      onLogin('full');
      return;
    }

    setError('رمز الدخول غير صحيح، يرجى المحاولة مرة أخرى');
  };

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-[#F5F7F8] text-[#1E293B] flex flex-col items-center justify-center p-4 select-none"
    >
      <div className="w-full max-w-md bg-white rounded-xl border border-[#E2E8EE] shadow-sm overflow-hidden">
        {/* Top Brand Header */}
        <div className="bg-[#1C252C] text-white px-6 py-6 border-b border-[#2A3741] text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[#0F766E]/20 border border-[#5EEAD4]/30 text-[#5EEAD4] mb-3">
            <Lock className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-black tracking-tight">أحمد القيسي للإطارات والبطاريات</h1>
          <p className="text-xs font-semibold text-[#90A4B4] mt-1">
            نظام نقاط البيع وإدارة الفواتير
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label
              htmlFor="access-code-input"
              className="block text-xs font-extrabold text-[#334155] mb-2"
            >
              رمز الدخول
            </label>
            <div className="relative">
              <input
                id="access-code-input"
                type={showCode ? 'text' : 'password'}
                inputMode="numeric"
                autoComplete="off"
                autoFocus
                dir="ltr"
                value={code}
                onChange={(e) => {
                  setCode(e.target.value);
                  if (error) setError(null);
                }}
                className={`w-full h-11 px-4 pl-11 rounded-lg bg-[#F8FAFB] focus:bg-white border text-center text-base font-extrabold tracking-[0.22em] tabular-nums transition-colors focus:outline-none focus:ring-2 ${
                  error
                    ? 'border-[#BE123C] focus:border-[#BE123C] focus:ring-[rgba(190,18,60,0.16)] text-[#BE123C]'
                    : 'border-[#CBD5E1] focus:border-[#0F766E] focus:ring-[rgba(15,118,110,0.18)] text-[#1E293B]'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowCode((prev) => !prev)}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-[#64748B] hover:text-[#1E293B] hover:bg-[#E2E8EE]/60 transition-colors cursor-pointer"
                aria-label={showCode ? 'إخفاء الرمز' : 'إظهار الرمز'}
                title={showCode ? 'إخفاء الرمز' : 'إظهار الرمز'}
              >
                {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {error ? (
              <div
                role="alert"
                className="mt-2.5 flex items-center gap-1.5 text-xs font-bold text-[#BE123C]"
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            ) : (
              <p className="mt-2 text-[11px] font-semibold text-[#64748B]">
                أدخل رمز الدخول للوصول إلى النسخة التجريبية أو كاملة الصلاحيات
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full h-11 rounded-lg bg-[#0F766E] hover:bg-[#115E59] active:scale-[0.99] text-white font-extrabold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            <span>دخول إلى النظام</span>
          </button>
        </form>
      </div>
    </div>
  );
};
