import { AppSettings, Invoice, InvoiceItem } from '../types';

const STORAGE_KEYS = {
  INVOICES: 'alqaisi_pos_invoices_v1',
  SETTINGS: 'alqaisi_pos_settings_v1',
  LAST_SERIAL: 'alqaisi_pos_last_serial_v1',
} as const;

export const FIXED_BANNER_IMAGE = './assets/aistudio/IMG_________________995_107ca5c1.jpg';
export const FIXED_SHOP_ADDRESS = 'ديالى - بعقوبة - حي المعلمين';
export const FIXED_SHOP_PHONE = '07715961340 - 07805807308';

export const DEFAULT_SETTINGS: AppSettings = {
  bannerImage: FIXED_BANNER_IMAGE,
  shopAddress: FIXED_SHOP_ADDRESS,
  shopPhone: FIXED_SHOP_PHONE,
  paperSize: 'A4_PORTRAIT',
  selectedPrinter: '',
  silentPrint: false,
};

export function createEmptyItem(): InvoiceItem {
  return {
    id: generateId(),
    name: '',
    quantity: 1,
    unitPrice: 0,
    warranty: '',
    notes: '',
  };
}

export function generateId(): string {
  return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function formatSerialNumber(num: number): string {
  return `#${String(num).padStart(4, '0')}`;
}

export function formatIqd(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.max(0, Math.round(amount)) : 0;
  return safe.toLocaleString('en-US');
}

export function getInvoiceTotalIqd(invoice: Invoice): number {
  if (typeof invoice.totalIqd === 'number' && Number.isFinite(invoice.totalIqd)) {
    return invoice.totalIqd;
  }
  if (typeof invoice.iqdAmount === 'number' && Number.isFinite(invoice.iqdAmount)) {
    return invoice.iqdAmount;
  }
  return invoice.items.reduce(
    (sum, it) => sum + (Number(it.quantity) || 0) * (Number(it.unitPrice) || 0),
    0
  );
}

/** Converts Arabic-Indic (٠-٩) and Extended Arabic-Indic (۰-۹) digits to Western digits and strips non-digits. */
export function parseNumericInput(raw: string): number {
  const normalized = raw
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[^0-9]/g, '');
  if (!normalized) return 0;
  const parsed = Number.parseInt(normalized, 10);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function formatDateYYYYMMDD(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}/${m}/${d}`;
}

export function formatTimeArabic12h(date: Date): string {
  const hours24 = date.getHours();
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const period = hours24 >= 12 ? 'م' : 'ص';
  const hours12 = hours24 % 12 || 12;
  const hh = String(hours12).padStart(2, '0');
  return `${hh}:${minutes} ${period}`;
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      bannerImage: FIXED_BANNER_IMAGE,
      shopAddress: FIXED_SHOP_ADDRESS,
      shopPhone: FIXED_SHOP_PHONE,
      paperSize: 'A4_PORTRAIT',
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): boolean {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    return true;
  } catch {
    return false;
  }
}

export function loadInvoices(): Invoice[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.INVOICES);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed as Invoice[];
  } catch {
    return [];
  }
}

export function saveInvoices(invoices: Invoice[]): boolean {
  try {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    return true;
  } catch {
    return false;
  }
}

export function getLastSerial(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LAST_SERIAL);
    const parsed = raw ? Number.parseInt(raw, 10) : 0;
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
  } catch {
    return 0;
  }
}

export function saveLastSerial(serial: number): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LAST_SERIAL, String(serial));
  } catch {
    // ignore quota issues
  }
}

export function clearAllPosLocalStorage(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.INVOICES);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.LAST_SERIAL);
  } catch {
    // ignore storage errors
  }
}

export function getNextSerialNumber(invoices: Invoice[]): number {
  const storedLast = getLastSerial();
  const maxInList = invoices.reduce((max, inv) => Math.max(max, inv.numericSerial || 0), 0);
  return Math.max(storedLast, maxInList) + 1;
}

export function collectProductSuggestions(invoices: Invoice[]): string[] {
  const seen = new Set<string>();
  for (const inv of invoices) {
    for (const item of inv.items) {
      const trimmed = item.name.trim();
      if (trimmed) {
        seen.add(trimmed);
      }
    }
  }
  return Array.from(seen);
}

export function getPaymentMethodLabel(method: 'cash' | 'card' | 'transfer'): string {
  switch (method) {
    case 'cash':
      return 'نقداً';
    case 'card':
      return 'بطاقة';
    case 'transfer':
      return 'تحويل';
  }
}

/** Compress uploaded banner image via canvas so it stays lightweight inside localStorage. */
export function compressImageToDataUrl(file: File, maxWidth = 1400, quality = 0.85): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('فشل قراءة ملف الصورة'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('الملف المختار ليس صورة صالحة'));
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const width = Math.round(img.width * scale);
        const height = Math.round(img.height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result));
          return;
        }
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
